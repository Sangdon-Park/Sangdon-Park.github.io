"""Generate past the wanted ending; remove only an explicitly located tail marker.

ASR locates the marker approximately. A sustained acoustic silence, not a word
timestamp, determines the cut. Ambiguous cases are rejected for regeneration.
"""
import re, math
import numpy as np
from scipy.signal import resample_poly
from faster_whisper import WhisperModel
import presentation_tts as pt

MARKER = '감사합니다.'
VERSION = 'protected-ending-gratitude-silence-v2'
_ASR = None

def generation_text(text):
    return text.rstrip() + '\n\n' + MARKER

def recognize_tail(wave, sr, seconds=6):
    global _ASR
    if _ASR is None:
        _ASR = WhisperModel(pt.cfg()['asr_model'], device='cpu', compute_type='int8', cpu_threads=4, local_files_only=True)
    offset = max(0, len(wave) / sr - seconds)
    tail = wave[round(offset * sr):]
    g = math.gcd(sr, 16000)
    tail = resample_poly(tail, 16000 // g, sr // g).astype(np.float32)
    chunks, _ = _ASR.transcribe(tail, language='ko', word_timestamps=True, beam_size=5, temperature=0.0, condition_on_previous_text=False, vad_filter=False)
    chunks = list(chunks)
    words = [{'word': w.word, 'start': w.start + offset, 'end': w.end + offset} for c in chunks for w in (c.words or [])]
    return words, ' '.join(c.text.strip() for c in chunks)

def protect(wave, sr, speech):
    a = np.asarray(wave, dtype=np.float32)
    words, recognized = recognize_tail(a, sr)
    candidates = [i for i, word in enumerate(words) if re.sub(r'[^가-힣]', '', word['word']) == '감사합니다']
    if not candidates or candidates[-1] == 0:
        raise ValueError('별도의 후속 어절이 확인되지 않아 절단하지 않았습니다: ' + recognized)
    i = candidates[-1]
    marker, previous = words[i], words[i - 1]
    # Prefer explicit sentence separation. Never infer a cut from output length alone.
    hop, frame = round(sr * .005), round(sr * .02)
    squared = np.pad(a.astype(np.float64) ** 2, (frame // 2, frame // 2))
    cumsum = np.concatenate(([0.], np.cumsum(squared)))
    starts = np.arange(0, len(a), hop)
    rms = np.sqrt((cumsum[starts + frame] - cumsum[starts]) / frame)
    peak = float(rms.max())
    if peak < .001:
        raise ValueError('발화 에너지가 너무 작습니다.')
    db = 20 * np.log10(np.maximum(rms, 1e-9) / peak)
    voiced = np.flatnonzero(db > -30)
    voiced_end = voiced[-1] * hop / sr
    collapsed = marker['start'] - previous['end'] < .03
    lo = max(0, previous['end'] - .04, voiced_end - 1.5)
    hi = min(len(a) / sr - .3, marker['start'] + .55)
    if not collapsed:
        lo = max(lo, marker['start'] - .32)
    all_gaps = []
    for threshold in [-38, -35, -32, -30]:
        quiet = db < threshold
        k = max(0, int(lo * sr / hop))
        while k < min(len(quiet), int(hi * sr / hop)):
            if not quiet[k]:
                k += 1
                continue
            begin = k
            while k < len(quiet) and quiet[k]:
                k += 1
            start, end = begin * hop / sr, k * hop / sr
            # A stop closure inside '니다' is shorter than this required pause.
            if end - start >= .075 and lo <= end <= hi and .3 <= voiced_end - end <= 1.5:
                score = abs(end - (voiced_end - .72 if collapsed else marker['start']))
                all_gaps.append({'start': start, 'end': end, 'threshold_db': threshold, 'score': score})
        if all_gaps:
            break
    if not all_gaps:
        raise ValueError('후속 어절 앞의 충분한 무음이 없어 재합성이 필요합니다: ' + recognized)
    gap = min(all_gaps, key=lambda g: g['score'])
    if gap['score'] > .42:
        raise ValueError('후속 어절과 무음 골의 위치가 모호합니다.')
    cut_seconds = gap['end'] - .025
    n = int(cut_seconds * sr)
    # Choose a zero crossing inside already-quiet audio; never fade the final vowel.
    lo_sample, hi_sample = max(0, n - round(.005 * sr)), min(len(a), n + round(.005 * sr))
    n = lo_sample + int(np.argmin(np.abs(a[lo_sample:hi_sample])))
    prefix = a[:n].copy()
    quiet_tail = max(0., n / sr - gap['start'])
    padding = round(max(0, .22 - quiet_tail) * sr)
    output = np.pad(prefix, (0, padding))
    detail = {'policy': VERSION, 'raw_generation_seconds': len(a) / sr, 'expected_speech': speech, 'marker': MARKER, 'raw_tail_recognized': recognized, 'marker_asr': marker, 'previous_asr': previous, 'cut_gap': gap, 'cut_sample': n, 'cut_seconds': n / sr, 'output_samples': len(output), 'added_silence_seconds': padding / sr, 'prefix_samples_unchanged': True, 'cut_directly_at_asr_timestamp': False, 'speech_fade_applied': False}
    return output, detail
