"""Preserve raw TTS, check every ending, and align sentences for highlighting.

ASR times are used for screen cues only. They never cut the narration waveform.
"""
from pathlib import Path
import json,re,shutil,math,argparse,difflib
import numpy as np,soundfile as sf
from scipy.signal import resample_poly
from faster_whisper import WhisperModel
import presentation_tts as pt
from audit_speech import normalized,cer

def sentence_parts(t):return re.split(r'(?<=[.!?])\s+',t.strip())

def sentence_times(speech,caption,words,duration):
 texts=sentence_parts(speech);caps=sentence_parts(caption)
 if len(caps)!=len(texts):raise ValueError('자막과 발화 문장 수가 다릅니다.')
 target=''.join(normalized(t) for t in texts);actual='';char_words=[]
 for word in words:
  chars=normalized(word['word']);actual+=chars;char_words.extend([word]*len(chars))
 matcher=difflib.SequenceMatcher(None,target,actual,autojunk=False)
 mapping={}
 for block in matcher.get_matching_blocks():
  for j in range(block.size):mapping[block.a+j]=block.b+j
 anchors=sorted(mapping);out=[];cursor=0
 for i,(text,cap) in enumerate(zip(texts,caps),1):
  length=len(normalized(text));begin=cursor;end=cursor+length;cursor=end
  matches=[p for p in anchors if begin<=p<end]
  if matches and char_words:
   start=max(0,float(char_words[mapping[matches[0]]]['start'])-.04)
   stop=min(duration,float(char_words[mapping[matches[-1]]]['end'])+.12)
   mode='ASR words matched to script'
  else:
   start=duration*begin/max(len(target),1);stop=duration*end/max(len(target),1);mode='proportional fallback'
  out.append({'sentence':i,'speech':text,'caption':cap,'start':start,'end':max(stop,start+.03),'mode':mode})
 for a,b in zip(out,out[1:]):
  if a['end']>b['start']:
   boundary=(a['end']+b['start'])/2;a['end']=boundary;b['start']=boundary
 return out

def process(track,available=False):
 K=pt.ROOT;job=K/'output'/track;rawdir=job/'raw_segments';rawdir.mkdir(exist_ok=True)
 cache=job/'alignment';cache.mkdir(exist_ok=True)
 model=WhisperModel(pt.cfg()['asr_model'],device='cpu',compute_type='int8',cpu_threads=6,local_files_only=True)
 timing=pt.read(job/'timing.json');result=[];total=sum(len(r['segments']) for r in timing['slides']);done=0
 for row in timing['slides']:
  for j,seg in enumerate(row['segments'],1):
   wav=job/seg['file'];meta=pt.read(wav.with_suffix('.json'));raw=rawdir/wav.name;rawmeta=raw.with_suffix('.json')
   if available and not meta.get('continuation_protection'):continue
   if not raw.exists() or not rawmeta.exists() or pt.read(rawmeta).get('key')!=meta['key'] or (not meta.get('ending_safety') and pt.filehash(raw)!=pt.filehash(wav)):
    if raw.exists():
     old=job/'audio_old';old.mkdir(exist_ok=True);shutil.copy2(raw,old/(raw.stem+'-'+pt.filehash(raw)[:10]+'.wav'))
    shutil.copy2(wav,raw);shutil.copy2(wav.with_suffix('.json'),rawmeta)
   a,sr=sf.read(raw,dtype='float32');duration=len(a)/sr
   frame=max(1,round(.02*sr));hop=max(1,round(.01*sr))
   energy=np.array([np.sqrt(np.mean(a[k:min(len(a),k+frame)]**2)) for k in range(0,len(a),hop)])
   threshold=max(.0005,float(energy.max())*.01);active=np.flatnonzero(energy>threshold)
   last_active=min(duration,(active[-1]*hop+frame)/sr) if len(active) else 0
   trailing=max(0,duration-last_active);pad=max(0,round((.15-trailing)*sr))
   processed=np.pad(a,(0,pad)) if pad else a
   safety={'raw_seconds':duration,'raw_trailing_energy_margin':trailing,'added_silence_seconds':pad/sr,'preserved_all_raw_samples':True,'asr_used_as_audio_cut':False,'raw_last_frame_active':bool(energy[-1]>threshold*2),'output_trailing_margin':trailing+pad/sr}
   protection=meta.get('continuation_protection')
   if not protection or protection.get('policy')!='protected-ending-gratitude-silence-v2':
    raise ValueError(f'{wav.name}: 생성 단계에서 어미를 보호한 새 음성이 필요합니다. 기존 검사로 통과시키지 않습니다.')
   safety['generation_protection']=protection
   receipt=cache/(wav.stem+'.json');key=pt.digest(pt.filehash(raw),seg['speech'],'word-and-tail-v1')
   if receipt.exists() and pt.read(receipt).get('key')==key:check=pt.read(receipt)
   else:
    segments,_=model.transcribe(str(raw),language='ko',beam_size=5,temperature=0.0,condition_on_previous_text=False,word_timestamps=True,vad_filter=True,initial_prompt='컴퓨터공학과, 채용 공고, 박상돈, 데이터베이스, 닷넷 실행 환경, 난수 시드, 제안 방법, 플로피 서바이버즈, 헥사곤 수프.')
    chunks=list(segments);text=' '.join(s.text.strip() for s in chunks)
    words=[{'word':w.word,'start':w.start,'end':w.end,'probability':w.probability} for s in chunks for w in (s.words or [])]
    tail=a[-min(len(a),int(5*sr)):];g=math.gcd(sr,16000);tail16=resample_poly(tail,16000//g,sr//g)
    tails,_=model.transcribe(tail16,language='ko',beam_size=1,temperature=0.0,condition_on_previous_text=False,vad_filter=False)
    tail_text=' '.join(s.text.strip() for s in tails)
    expected=normalized(seg['speech']);observed=normalized(tail_text)
    ending_ratio=difflib.SequenceMatcher(None,expected[-7:],observed[-7:],autojunk=False).ratio()
    ending_ok=bool(observed and expected[-1:]==observed[-1:] and ending_ratio>=.70)
    check={'key':key,'file':wav.name,'speech':seg['speech'],'recognized':text,'normalized_cer':cer(seg['speech'],text),'tail_recognized':tail_text,'ending_ratio':ending_ratio,'ending_text_ok':ending_ok,'words':words}
    pt.write(receipt,check)
   # Padding is rebuilt from the untouched raw file, so reruns cannot accumulate silence.
   temporary=wav.with_suffix('.protected.wav');sf.write(temporary,processed,sr,subtype='PCM_16');temporary.replace(wav)
   meta['ending_safety']=safety;pt.write(wav.with_suffix('.json'),meta)
   seg['seconds']=len(processed)/sr;seg['sample_rate']=sr
   seg['sentences']=sentence_times(seg['speech'],seg['caption'],check['words'],seg['seconds'])
   record={k:v for k,v in check.items() if k!='words'};record['safety']=safety;record['slide']=row['number'];record['segment']=j
   record['boundary_warning']=safety['raw_last_frame_active']
   record['boundary_handling']='Full marker-bearing generation retained separately; wanted speech cut only in a sustained acoustic silence before the identified marker.'
   record['review_needed']=not check['ending_text_ok'] or check['normalized_cer']>.12
   result.append(record);done+=1
   if record['review_needed']:print(json.dumps(record,ensure_ascii=False),flush=True)
   if done%10==0 or done==total:print(f'{track}: 문장 정렬·어미 검사 {done}/{total}',flush=True)
 if not available:pt.write(job/'timing.json',timing)
 if not result:
  print(f'{track}: 새 방식으로 완료된 문단을 기다립니다.',flush=True);return
 report={'track':track,'segments':result,'count':len(result),'review_count':sum(r['review_needed'] for r in result),'raw_preserved':True,'no_asr_audio_cuts':True,'minimum_tail_seconds':min(r['safety']['output_trailing_margin'] for r in result),'average_normalized_cer':float(np.mean([r['normalized_cer'] for r in result]))}
 pt.write(job/('partial-ending-check.json' if available else 'ending-check.json'),report);print(json.dumps({k:v for k,v in report.items() if k!='segments'},ensure_ascii=False),flush=True)
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--track',choices=['lecture','portfolio'],required=True);a.add_argument('--available',action='store_true');args=a.parse_args();process(args.track,args.available)
