"""Independent, greedy Korean CTC tail decoding, without an external LM."""
import argparse, json, math, re
from pathlib import Path
import numpy as np
import soundfile as sf
import torch
from scipy.signal import resample_poly
from transformers import Wav2Vec2ForCTC, Wav2Vec2Processor
import presentation_tts as pt

def clean(text):return re.sub(r'[^가-힣]','',text)

def run(track=None,pilot=False):
    model_dir=Path('C:/Users/HP-SERVER/.cache/career-tts/models/korean-ctc')
    torch.set_num_threads(4)
    processor=Wav2Vec2Processor.from_pretrained(model_dir,local_files_only=True)
    model=Wav2Vec2ForCTC.from_pretrained(model_dir,local_files_only=True,use_safetensors=True).eval()
    items=[]
    if pilot:
        folder=pt.ROOT/'checks/ending-repair-pilot'
        for meta in sorted(folder.glob('*.json')):
            if meta.name=='results.json':continue
            entry=pt.read(meta)
            if 'expected_speech' not in entry:continue
            name=meta.stem;t,n,j=name.split('_');stem=f'slide_{n}_{j}.wav'
            for kind,path in [('before',pt.ROOT/'audio_old/before-ending-generation-v2'/t/'segments'/stem),('after',folder/(name+'.new.wav'))]:
                items.append({'file':str(path),'speech':entry['expected_speech'],'kind':kind})
        destination=folder/'ctc-check.json'
    else:
        job=pt.ROOT/'output'/track
        for row in pt.read(job/'timing.json')['slides']:
            for j,segment in enumerate(row['segments'],1):items.append({'file':str(job/segment['file']),'speech':segment['speech'],'slide':row['number'],'segment':j})
        destination=job/'ctc-ending-check.json'
    rows=[]
    for i,item in enumerate(items,1):
        wave,sr=sf.read(item['file'],dtype='float32')
        wave=wave[-min(len(wave),round(sr*4)):]
        g=math.gcd(sr,16000);wave=resample_poly(wave,16000//g,sr//g).astype(np.float32)
        inputs=processor(wave,sampling_rate=16000,return_tensors='pt')
        with torch.inference_mode():logits=model(**inputs).logits[0]
        ids=logits.argmax(-1);decoded=processor.decode(ids)
        target=clean(item['speech']);observed=clean(decoded)
        wanted_id=processor.tokenizer.convert_tokens_to_ids(target[-1])
        probabilities=logits.softmax(-1)
        emitted=ids==wanted_id
        frames=torch.flatnonzero(emitted).tolist() if hasattr(torch,'flatnonzero') else torch.nonzero(emitted).flatten().tolist()
        result={**item,'recognized_tail':decoded,'expected_last_syllable':target[-1],'observed_last_syllable':observed[-1:] if observed else '', 'last_syllable_matches':bool(observed and observed[-1]==target[-1]),'last_three_match':bool(observed.endswith(target[-3:])), 'expected_syllable_max_posterior':float(probabilities[-35:,wanted_id].max()),'expected_syllable_greedy_frames':frames[-12:]}
        rows.append(result)
        if pilot or not result['last_three_match']:print(json.dumps(result,ensure_ascii=False),flush=True)
        if i%20==0:print(f'CTC 끝음절 검사 {i}/{len(items)}',flush=True)
    summary={'method':'Wav2Vec2 Korean greedy CTC; no language-model decoder; diagnostic, not a substitute for listening','count':len(rows),'last_syllable_mismatch_count':sum(not r['last_syllable_matches'] for r in rows),'last_three_mismatch_count':sum(not r['last_three_match'] for r in rows),'segments':rows}
    pt.write(destination,summary)
    print(json.dumps({k:v for k,v in summary.items() if k!='segments'},ensure_ascii=False),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--track',choices=['lecture','portfolio']);parser.add_argument('--pilot',action='store_true');args=parser.parse_args()
    run(args.track,args.pilot)
