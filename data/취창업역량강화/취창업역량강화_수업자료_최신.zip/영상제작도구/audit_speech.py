"""Local ASR checks for generated narration; cached by audio and target text."""
from pathlib import Path
import argparse,json,re,csv
import presentation_tts as pt

def sino(n):
 n=int(n)
 if n==0:return '영'
 digits='영일이삼사오육칠팔구';out='';group=0
 while n:
  part=n%10000;n//=10000;piece=''
  for i,unit in reversed(list(enumerate(['','십','백','천']))):
   d=part//(10**i)%10
   if d:piece+=('' if d==1 and i else digits[d])+unit
  if piece:
   if piece=='일' and group==1:piece=''
   out=piece+['','만','억','조'][group]+out
  group+=1
 return out

def normalized(text):
 glossary=pt.read(pt.ROOT/'pronunciation.json')
 for term,value in sorted(glossary.items(),key=lambda x:-len(x[0])):
  text=re.sub(re.escape(term),value,text,flags=re.I)
 text=text.replace('%','퍼센트').replace(',','')
 def number(m):
  x=m.group().split('.');r=sino(x[0])
  if len(x)>1:r+='점'+''.join('영일이삼사오육칠팔구'[int(c)] for c in x[1])
  return r
 text=re.sub(r'\d+(?:\.\d+)?',number,text)
 natives={'열두':'십이','열한':'십일','열':'십','아홉':'구','여덟':'팔','일곱':'칠','여섯':'육','다섯':'오','네':'사','세':'삼','두':'이','한':'일'}
 for word,value in natives.items():text=re.sub(word+r'(?=\s*(?:번|개|명|건|단계|가지|과목|시간))',value,text)
 return re.sub(r'[^가-힣a-z0-9]','',text.lower())

def cer(expected,actual):
 a,b=normalized(expected),normalized(actual);cost=list(range(len(b)+1))
 for i,x in enumerate(a,1):
  nxt=[i]
  for j,y in enumerate(b,1):nxt.append(min(nxt[-1]+1,cost[j]+1,cost[j-1]+(x!=y)))
  cost=nxt
 return cost[-1]/max(1,len(a))

def audit(track):
 from faster_whisper import WhisperModel
 job=pt.ROOT/'output'/track;cache=job/'audit';cache.mkdir(parents=True,exist_ok=True)
 model=None;results=[]
 context='컴퓨터공학과, 채용 공고, 알고리즘, 박상돈, 데이터베이스, 플로피 서바이버즈, 헥사곤 수프, 리드미, 카이스트, 백엔드.'
 for wav in sorted((job/'segments').glob('*.wav')):
  if wav.stem.endswith('.new') or not wav.with_suffix('.json').is_file():continue
  meta=pt.read(wav.with_suffix('.json'));target=meta['speech'];key=pt.digest(pt.filehash(wav),target,'small-ko-v1');resultfile=cache/(wav.stem+'.json')
  if resultfile.exists() and pt.read(resultfile).get('key')==key:row=pt.read(resultfile)
  else:
   if model is None:model=WhisperModel(pt.cfg()['asr_model'],device='cpu',compute_type='int8',local_files_only=True)
   segments,_=model.transcribe(str(wav),language='ko',beam_size=5,vad_filter=True,condition_on_previous_text=False,initial_prompt=context)
   observed=' '.join(s.text.strip() for s in segments)
   error=cer(target,observed)
   row={'key':key,'file':wav.name,'expected':target,'recognized':observed,'normalized_cer':error,'review_needed':error>.12}
   pt.write(resultfile,row)
  important=['사천건','팔점삼오','이십일점삼퍼센트','백만육천오백구십이바이트','이만천구십','만삼천오백십일','삼십오점구퍼센트']
  expected_normal=normalized(target);actual_normal=normalized(row['recognized'])
  row['missing_quantities']=[term for term in important if term in expected_normal and term not in actual_normal]
  if row['missing_quantities']:row['review_needed']=True
  results.append(row)
  if row['review_needed']:print(json.dumps(row,ensure_ascii=False),flush=True)
 report={'track':track,'checked_segments':len(results),'review_count':sum(r['review_needed'] for r in results),'average_normalized_cer':sum(r['normalized_cer'] for r in results)/max(1,len(results)),'purpose':'ASR content check; not a voice-similarity or listening assessment','segments':results}
 pt.write(job/'speech-audit.json',report)
 with (job/'speech-audit.csv').open('w',encoding='utf-8-sig',newline='') as f:
  writer=csv.DictWriter(f,fieldnames=['file','expected','recognized','normalized_cer','review_needed']);writer.writeheader();writer.writerows({k:r[k] for k in writer.fieldnames} for r in results)
 print(json.dumps({k:v for k,v in report.items() if k!='segments'},ensure_ascii=False),flush=True)
 return report
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--track',choices=['lecture','portfolio','lecture-sample'],required=True)
 audit(ap.parse_args().track)
