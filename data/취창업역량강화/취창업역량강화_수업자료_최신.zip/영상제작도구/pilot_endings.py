"""Audible before/after samples for the reported truncated Korean ending."""
import json
from pathlib import Path
import numpy as np
import soundfile as sf
import torch
import presentation_tts as pt
import protected_endings as pe

def main():
    job = pt.ROOT / 'checks/ending-repair-pilot'
    job.mkdir(parents=True, exist_ok=True)
    selections = [('lecture',1,2), ('lecture',1,3), ('lecture',27,2), ('portfolio',8,2)]
    model = pt.load_model(pt.cfg())
    reference = pt.voice(pt.cfg())
    prompt = model.create_voice_clone_prompt(ref_audio=reference['audio'], ref_text=reference['transcript'], x_vector_only_mode=False)
    texts = [pt.records(t)[n-1]['segments'][j-1]['speech'] for t,n,j in selections]
    torch.manual_seed(27402026)
    with torch.inference_mode():
        waves, sr = model.generate_voice_clone(text=[pe.generation_text(t) for t in texts], language='Korean', voice_clone_prompt=prompt, non_streaming_mode=True, max_new_tokens=2400)
    rows = []
    for (track,number,segment), text, wave in zip(selections,texts,waves):
        stem = f'{track}_{number:02d}_{segment:02d}'
        wave, quality = pt.audio_check(wave,sr,text)
        sf.write(job/(stem+'.raw.wav'),wave,sr,subtype='PCM_16')
        try:
            protected, detail = pe.protect(wave,sr,text)
            sf.write(job/(stem+'.new.wav'),protected,sr,subtype='PCM_16')
            old, old_sr = sf.read(pt.ROOT/'output'/track/'segments'/f'slide_{number:02d}_{segment:02d}.wav',dtype='float32')
            assert old_sr==sr
            pieces = [old[-min(len(old),sr*5):],np.zeros(sr),protected[-min(len(protected),sr*5):]]
            comparison = np.concatenate(pieces)
            comparison *= min(8., .9/max(float(np.max(np.abs(comparison))),.001))
            sf.write(job/(stem+'.before-after.wav'),comparison,sr,subtype='PCM_16')
            pt.write(job/(stem+'.json'),detail)
            rows.append({'file':stem,'success':True,'gap':detail['cut_gap'],'comparison':str(job/(stem+'.before-after.wav'))})
        except ValueError as error:
            rows.append({'file':stem,'success':False,'error':str(error)})
    pt.write(job/'results.json',rows)
    print(json.dumps(rows,ensure_ascii=False),flush=True)

if __name__=='__main__':main()
