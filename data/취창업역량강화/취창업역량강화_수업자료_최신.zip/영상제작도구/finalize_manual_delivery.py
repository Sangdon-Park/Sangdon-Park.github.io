"""Package current documents and local voice videos after visual acceptance."""
from pathlib import Path
import csv, json, shutil, zipfile
import presentation_tts as pt

K = pt.ROOT
DATA = Path('C:/Github/Sangdon-Park.github.io/data/취창업역량강화')
OUT = DATA / '설명형_개정본'
DESKTOP = Path('C:/Users/HP-SERVER/Desktop/취창업역량강화_발표영상')
PREVIOUS_NAMES = {'lecture': '01_취창업역량강화_강의_박상돈', 'portfolio': '02_포트폴리오_설명_박상돈'}
NAMES = {track: name + '_어미수정판' for track, name in PREVIOUS_NAMES.items()}

def duration(seconds):
    minutes, seconds = divmod(round(seconds), 60)
    return f'{minutes}분 {seconds:02d}초'

def docs(stats):
    guide = f'''# 어미 수정판 영상과 다시 만드는 방법

바탕화면의 `취창업역량강화_발표영상` 폴더에서 바로 재생할 수 있습니다.

‘정리하겠습니ㄷ’처럼 끝음절이 덜 발음되는 문제를 고치기 위해 전체 150개 문단을 다시 합성했습니다. 교수님이 비교 음성에서 끝의 ‘다’가 온전하다고 확인한 방식입니다. 본문 뒤에 보호용 후속 어절까지 생성한 뒤 실제 무음에서 분리했습니다. 새 음성에 맞춰 자막·강조 시각도 다시 계산했습니다. 아래 `_어미수정판` 파일이 최신 결과이며, 기존 이름의 영상도 같은 내용으로 교체했습니다.

- `{NAMES['lecture']}.mp4`: 강의 36장, {duration(stats['lecture']['audio_seconds'])}
- `{NAMES['portfolio']}.mp4`: 실제 경력·프로젝트 포트폴리오 8쪽, {duration(stats['portfolio']['audio_seconds'])}
- 같은 이름의 SRT는 자막 편집용, CSV는 슬라이드별 시작·종료 시각입니다.

두 영상은 바탕화면의 `녹음 (9).m4a`를 참조해 만든 합성 내레이션입니다. 약 66초 원본 중 1.10~17.10초 구간을 사용했습니다. 녹음 자체를 이어 붙인 발표나 별도 미세학습 결과는 아닙니다.

## 현재 PC에서 다시 만들기

실행 폴더는 `C:\\Github\\TTS\\career-presentation`입니다. 목소리는 등록되어 있습니다.

1. `01_환경확인.cmd`: 모델·GPU·참조 음성을 확인합니다.
2. `02_목소리_샘플합성.cmd`: 첫 장의 목소리와 말투를 들어볼 수 있습니다.
3. `03_발표영상_만들기.cmd`: 강의의 변경된 음성만 합성하고 문장 정렬·어미 검사·화자 비교·강조 영상 제작을 실행합니다.
4. `04_포트폴리오영상_만들기.cmd`: 포트폴리오에도 같은 절차를 적용합니다.

원본 결과는 `output/lecture`와 `output/portfolio`에 생성됩니다. 다시 만든 영상은 새 자막·강조 화면을 검수한 뒤 바탕화면에 반영합니다. `checks/visual-review-*.json`에는 실제로 확인한 새 프레임의 해시가 필요합니다. 검수 기록을 갱신한 다음 `accept_delivery.py`, `write_application_report.py`, `finalize_manual_delivery.py` 순서로 실행하면 검증된 복사본과 수업자료 ZIP이 갱신됩니다. 과거 영상의 검수 기록을 그대로 사용하면 복사를 중단합니다.

## 대본·화면을 고칠 때

PPT 발표자 노트의 출처를 제외한 본문을 발화 기준으로 맞췄고, 원문은 `notes_orig`에 보존했습니다. `manifest.json`의 `caption`은 원문 자막, `speech`는 숫자·영어·기호를 발음대로 바꾼 합성 원고입니다. `notes`는 읽기 편한 사본입니다. 대본 내용 변경은 PPT 노트·PDF 읽기 대본·manifest의 내용도 함께 맞춰야 합니다.

PPT를 수정하면 `assets_native/lecture/slide_NN.png`를 PowerPoint에서 1920×1080으로 다시 내보내고 해당 `highlights/designs/lecture/slide_NN.json`의 강조 대상을 확인합니다. PDF 페이지 이미지는 `assets/portfolio`에 있습니다. 문장 수를 바꾸면 `segment.sentence` 형식의 강조 문장 번호도 갱신합니다.

음성·원고·화면·강조 위치의 해시가 같으면 검증된 캐시를 재사용합니다. 특정 문단만 다시 뽑는 예시는 다음과 같습니다. 실행 폴더에서 PowerShell로 실행합니다.

```powershell
$taskPython = (Get-Content -LiteralPath '.\\config.json' -Raw -Encoding UTF8 | ConvertFrom-Json).python
& $taskPython -X utf8 .\\redo_segment.py --track lecture --slide 35 --segment 2 --render
```

기존 조각은 `audio_old`에 보존됩니다. 새 목소리로 바꿀 때만 `00_목소리_등록.cmd`를 사용합니다. 자동 검사에서 의심 문단이 발견되면 원본과 기존 영상을 남기고 `ending-check.json`에 확인 대상을 표시합니다.

## 수정 재료와 검사 기록

- `output/TRACK/generation_attempts`: 보호용 후속 어절까지 포함한 생성 원본과 각 시도의 판정. 실패한 시도도 보존합니다.
- `output/TRACK/raw_segments`: 후속 어절을 실제 무음 경계에서 분리한 뒤, 화면 시각을 정렬하기 전의 본문 음성.
- `output/TRACK/segments`: 영상에 쓸 본문 음성. 마지막 음절은 후속 어절 이전에 완성하도록 생성했고, 발화 부분에는 페이드를 적용하지 않았습니다.
- `output/TRACK/highlight/slide_NN`: 페이지별 MP4·WAV·자막·강조 시각·렌더 검사 결과.
- `output/TRACK/highlight/frames`: 실제 영상에서 추출한 모든 강조 장면의 검수 이미지.
- `output/TRACK/narration.wav`: 음량을 맞춘 연속 내레이션. `narration.raw.wav`도 보존합니다.
- `checks/visual-review-*.json`, `ending-check.json`, `speaker-check.json`: 화면·발화·화자 비교 기록.

자막과 강조의 문장 경계는 ASR 단어 시각과 원고를 대조했습니다. 두 줄을 넘는 긴 문장 안에서 자막을 추가로 나눌 때만 해당 문장 길이에 비례해 배분합니다.

이 PC에서는 Python 3.11, RTX 5090, PyTorch 2.8.0 CUDA 12.8, Qwen3-TTS Base 1.7B를 사용합니다. 이미 받은 모델로 합성할 때 녹음이나 원고를 외부 TTS 서비스로 보내지 않습니다. 모델은 사용자 캐시의 `career-tts/models`에 있습니다.

수업자료 ZIP에는 문서와 재제작 도구가 들어갑니다. 개인 녹음·참조 음성·합성 음성 원본·완성 영상·모델 가중치는 ZIP에 넣지 않았습니다. 영상은 바탕화면, 참조 음성과 모델은 이 PC의 실행 폴더·캐시에 있습니다. 다른 PC에서는 본인 참조를 별도로 등록하고 환경 경로를 설정해야 합니다.
'''
    (K / '사용방법.md').write_text(guide, encoding='utf-8')
    (OUT / '영상제작_안내.md').write_text(guide, encoding='utf-8')
    (DESKTOP / '먼저읽기.md').write_text(guide, encoding='utf-8')
    current = f'''# 최신 수업자료

최신 발표자료는 `설명형_개정본/취창업역량강화_전공과AI시대_박상돈.pptx` 36장입니다.
실제 경력 포트폴리오는 `포트폴리오_박상돈.pdf` 8쪽, 그대로 읽는 발표대본은 `그대로읽는_발표대본.pdf` 22쪽입니다.

강의에는 실제 당근 공고 분석, 백엔드 요청·저장·응답의 흐름, 대전대 컴공 전공 과목과 남길 결과물, AI 시대의 학습·검토 습관, 프로젝트·포트폴리오·면접, 12주 실행 계획을 담았습니다. 학생 실행계획서와 실제 작동하는 수업 예제도 함께 있습니다.

교수님 녹음을 참조한 강의 영상({duration(stats['lecture']['audio_seconds'])})과 포트폴리오 영상({duration(stats['portfolio']['audio_seconds'])})은 바탕화면 `취창업역량강화_발표영상` 폴더에 있습니다. 문장별 자막·강조 표시를 넣고, 음성과 전체 영상 파일을 검사했습니다.

전체 문서와 재제작 도구는 `취창업역량강화_수업자료_최신.zip`에 묶었습니다. 자세한 사용법은 `영상제작_안내.md`, 적용 내역은 `노하우_적용표.md`입니다. 이전의 18장 PPT와 모의 지원자 포트폴리오는 최신 자료가 아닙니다.
'''
    (DATA / '00_최신자료안내.md').write_text(current, encoding='utf-8')
    (OUT / '먼저읽기.txt').write_text(current.replace('설명형_개정본/', ''), encoding='utf-8')

def main():
    DESKTOP.mkdir(exist_ok=True)
    stats = {track: pt.read(K / 'output' / track / 'render-check.json') for track in NAMES}
    for track, check in stats.items():
        if not check.get('decoded_without_error') or check.get('visual_review_status') != 'passed':
            raise ValueError(f'최종 화면 검수가 필요합니다: {track}')
        job = K / 'output' / track
        assert check.get('ending_policy') == 'protected-ending-gratitude-silence-v2'
        assert check['video_sha256'] == pt.filehash(job / 'presentation.mp4')
        for source, suffix in [('presentation.mp4', '.mp4'), ('captions.srt', '.srt'), ('chapters.csv', '_목차.csv')]:
            shutil.copy2(job / source, DESKTOP / (NAMES[track] + suffix))
            shutil.copy2(job / source, DESKTOP / (PREVIOUS_NAMES[track] + suffix))
            assert pt.filehash(job / source) == pt.filehash(DESKTOP / (NAMES[track] + suffix)) == pt.filehash(DESKTOP / (PREVIOUS_NAMES[track] + suffix))
    docs(stats)
    for name in ['취창업역량강화_전공과AI시대_박상돈.pptx', '포트폴리오_박상돈.pdf', '그대로읽는_발표대본.pdf', '학생_취업준비_실행계획서.pdf']:
        shutil.copy2(OUT / name, DESKTOP / name)
    for name in ['노하우_적용표.md', '설치상태.md']:
        shutil.copy2(K / name, OUT / name)
        shutil.copy2(K / name, DESKTOP / name)
    bundle = DATA / '취창업역량강화_수업자료_최신.zip'
    if bundle.exists():
        backup = DATA / '이전자료_보관' / '수업자료_음성등록전.zip'
        if not backup.exists():
            backup.parent.mkdir(exist_ok=True)
            shutil.copy2(bundle, backup)
    temp = bundle.with_suffix('.new.zip')
    files = {}
    for path in OUT.rglob('*'):
        if path.is_file() and path.name != '백엔드지원준비_박상돈.pptx' and '__pycache__' not in path.parts and '.git' not in path.parts:
            files['수업자료/' + path.relative_to(OUT).as_posix()] = path
    include_dirs = ['source', 'assets', 'assets_native', 'notes', 'notes_orig', 'highlights/designs', 'highlights/design-input', 'vendor']
    for folder in include_dirs:
        for path in (K / folder).rglob('*'):
            if path.is_file() and '__pycache__' not in path.parts:
                files['영상제작도구/' + path.relative_to(K).as_posix()] = path
    for path in K.iterdir():
        if path.is_file() and path.suffix in ['.py', '.cmd', '.ps1', '.md', '.json', '.txt'] and path.name not in ['prepare_assets.py']:
            files['영상제작도구/' + path.name] = path
    for pattern in ['visual-review-*.json', 'notes-source-check.json', 'raw-preservation.json', 'campplus-model.json', 'delivery-check.json', 'ending-repair-summary.json', 'ending-repair-user-feedback.json', 'short-marker-gap-audit.json', 'korean-ctc-model.json']:
        for path in (K / 'checks').glob(pattern):
            files['영상제작도구/checks/' + path.name] = path
    with zipfile.ZipFile(temp, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, path in sorted(files.items()):
            archive.write(path, name)
    with zipfile.ZipFile(temp) as archive:
        assert archive.testzip() is None
        assert not any('/voice/' in name or '/raw_segments/' in name or name.endswith(('.wav', '.m4a', '.mp4', '.safetensors', '.bin')) for name in archive.namelist())
    temp.replace(bundle)
    shutil.copy2(bundle, DESKTOP / bundle.name)
    print(json.dumps({'desktop': str(DESKTOP), 'bundle': str(bundle), 'bundle_files': len(files), 'bundle_bytes': bundle.stat().st_size, 'videos': {t: s['audio_seconds'] for t, s in stats.items()}}, ensure_ascii=False))

if __name__ == '__main__':
    main()
