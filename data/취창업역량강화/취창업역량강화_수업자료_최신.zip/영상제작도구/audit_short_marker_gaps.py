"""Inspect the removed suffix at shorter acoustic gaps, as a diagnostic only.

An unexpected syllable before the marker is a reason to investigate a cut.
Matching ASR text does not establish audible completeness of the kept speech.
"""
import math
import re
import numpy as np
import soundfile as sf
import torch
from scipy.signal import resample_poly
from transformers import Wav2Vec2ForCTC, Wav2Vec2Processor
import presentation_tts as pt


def main():
    model_dir = pt.cfg()['ctc_model']
    torch.set_num_threads(4)
    processor = Wav2Vec2Processor.from_pretrained(model_dir, local_files_only=True)
    model = Wav2Vec2ForCTC.from_pretrained(model_dir, local_files_only=True, use_safetensors=True).eval()
    rows = []
    for track in ['lecture', 'portfolio']:
        job = pt.ROOT / 'output' / track
        for path in sorted((job / 'segments').glob('*.json')):
            protection = pt.read(path)['continuation_protection']
            gap = protection['cut_gap']['end'] - protection['cut_gap']['start']
            if gap > .125:
                continue
            wave, sr = sf.read(job / protection['full_generation_file'], dtype='float32')
            suffix = wave[protection['cut_sample']:]
            gcd = math.gcd(sr, 16000)
            suffix = resample_poly(suffix, 16000 // gcd, sr // gcd).astype(np.float32)
            inputs = processor(suffix, sampling_rate=16000, return_tensors='pt')
            with torch.inference_mode():
                ids = model(**inputs).logits[0].argmax(-1)
            text = processor.decode(ids)
            normalized = re.sub(r'[^가-힣]', '', text)
            row = {'track': track, 'segment': path.stem, 'quiet_gap_seconds': gap,
                   'removed_suffix_recognized': text, 'marker_only_recognized': normalized == '감사합니다',
                   'recognized_starts_with_marker': normalized.startswith('감사')}
            rows.append(row)
            print(row, flush=True)
    report = {'scope': 'Removed suffixes at gaps <= 125 ms', 'count': len(rows),
              'non_marker_transcriptions': sum(not row['marker_only_recognized'] for row in rows),
              'unexpected_prefix_count': sum(not row['recognized_starts_with_marker'] for row in rows),
              'interpretation': 'The removed suffix should begin with the sacrificial marker. Recognition differences within its ending are reported but do not concern the kept narration. All cases still require the separate acoustic gap and PCM preservation checks.',
              'limitation': 'Diagnostic only. The same CTC model previously reconstructed endings in a known defective clip. A marker-only transcript is not proof that the kept speech is audibly complete.',
              'rows': rows}
    pt.write(pt.ROOT / 'checks/short-marker-gap-audit.json', report)


if __name__ == '__main__':
    main()
