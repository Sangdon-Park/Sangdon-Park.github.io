"""Regenerate only the chosen paragraph while preserving its prior take."""
import argparse, shutil
import presentation_tts as pt

def redo(track, slide, segment, render=False):
    manifest = pt.read(pt.ROOT / 'manifest.json')
    row = next(r for r in manifest['tracks'][track] if r['number'] == slide)
    if not 1 <= segment <= len(row['segments']):
        raise ValueError('해당 문단 번호가 없습니다.')
    item = row['segments'][segment - 1]
    take = int(item.get('take', 0)) + 1
    backup = pt.ROOT / 'audio_old' / track / f'slide_{slide:02d}_{segment:02d}' / f'before_take_{take}'
    backup.mkdir(parents=True, exist_ok=False)
    job = pt.ROOT / 'output' / track
    for suffix in ['.wav', '.json']:
        source = job / 'segments' / f'slide_{slide:02d}_{segment:02d}{suffix}'
        if source.exists():
            shutil.copy2(source, backup / source.name)
    pt.write(backup / 'script.json', item)
    item['take'] = take
    pt.write(pt.ROOT / 'manifest.json', manifest)
    pt.synthesize(track)
    if render:
        pt.render(job)
    else:
        import align_and_check
        align_and_check.process(track)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--track', required=True, choices=['lecture', 'portfolio'])
    parser.add_argument('--slide', required=True, type=int)
    parser.add_argument('--segment', required=True, type=int)
    parser.add_argument('--render', action='store_true')
    args = parser.parse_args()
    redo(args.track, args.slide, args.segment, args.render)
