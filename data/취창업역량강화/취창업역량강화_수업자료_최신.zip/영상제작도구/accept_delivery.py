"""Bind completed visual reviews to the actual final media and validate timelines."""
import json
from pathlib import Path
import av
import soundfile as sf
import presentation_tts as pt

def main():
    reviews = {}
    for name in ['portfolio', 'lecture-01-12', 'lecture-13-24', 'lecture-25-36']:
        path = pt.ROOT / 'checks' / f'visual-review-{name}.json'
        review = pt.read(path)
        passed = review.get('overall_pass', review.get('all_pass', False))
        if not passed:
            raise ValueError(f'화면 재검수 대기: {name}')
        if review.get('ending_policy') != 'protected-ending-gratitude-silence-v2':
            raise ValueError(f'어미 수정판 화면 재검수 대기: {name}')
        frame_hashes = review.get('frame_hashes', [])
        if not frame_hashes:
            raise ValueError(f'실제 재검수 프레임 해시가 필요합니다: {name}')
        review_track = 'portfolio' if name == 'portfolio' else 'lecture'
        first, last = (1, 8) if name == 'portfolio' else tuple(map(int, name.split('-')[1:]))
        expected_frames = {str(path.resolve()) for number in range(first, last + 1)
                           for path in (pt.ROOT / 'output' / review_track / 'highlight/frames' / f'slide_{number:02d}').glob('frame_*.png')}
        assert expected_frames and {str(Path(f['path']).resolve()) for f in frame_hashes} == expected_frames, f'검수 범위 누락: {name}'
        for frame in frame_hashes:
            assert frame['sha256'] == pt.filehash(Path(frame['path'])), f'검수 뒤 프레임 변경: {frame["path"]}'
        reviews[name] = {'file': str(path), 'sha256': pt.filehash(path), 'passed': True}
    final = {}
    for track in ['lecture', 'portfolio']:
        job = pt.ROOT / 'output' / track
        progress=pt.read(job/'synthesis-progress.json')
        assert progress.get('complete') and progress.get('ending_policy')=='protected-ending-gratitude-silence-v2'
        check = pt.read(job / 'render-check.json')
        assert check['decoded_without_error']
        assert check['video_sha256'] == pt.filehash(job / 'presentation.mp4')
        assert pt.read(job / 'ending-check.json')['review_count'] == 0
        timeline = pt.read(job / 'timeline.json')
        protections=[]
        for segment in (job/'segments').glob('*.json'):
            protection=pt.read(segment).get('continuation_protection')
            assert protection and protection['policy']=='protected-ending-gratitude-silence-v2'
            assert protection['cut_gap']['end']-protection['cut_gap']['start']>=.075
            protections.append(protection)
        with av.open(str(job / 'presentation.mp4')) as container:
            video = container.streams.video[0]
            audio = container.streams.audio[0]
            media = {'width': video.width, 'height': video.height, 'fps': float(video.average_rate), 'video_codec': video.codec_context.name, 'audio_codec': audio.codec_context.name, 'video_frames': video.frames, 'video_seconds': float(video.duration * video.time_base), 'audio_seconds': float(audio.duration * audio.time_base)}
        assert (media['width'], media['height'], media['fps']) == (1920, 1080, 30)
        assert media['video_frames'] == timeline['frames']
        assert abs(media['audio_seconds'] - timeline['seconds']) < .05
        assert abs(media['video_seconds'] - timeline['seconds']) < 1 / 30
        wav = sf.info(job / 'narration.wav')
        assert abs(wav.duration - timeline['seconds']) < .0001
        last_end = 0
        for caption in timeline['captions']:
            assert 0 <= caption['start'] < caption['end'] <= timeline['seconds']
            assert caption['start'] >= last_end - .001
            assert 1 <= len(caption['text'].splitlines()) <= 2
            last_end = caption['end']
        frame_rows = []
        for path in sorted((job / 'highlight/frames').rglob('frame_*.png')):
            frame_rows.append({'path': str(path), 'sha256': pt.filehash(path)})
        assert len(frame_rows) == timeline['slide_count'] + timeline['highlight_count']
        check['visual_review_status'] = 'passed'
        check['reviewed_frames'] = len(frame_rows)
        check['ending_policy']='protected-ending-gratitude-silence-v2'
        check['protected_segments']=len(protections)
        check['media_metadata'] = media
        pt.write(job / 'render-check.json', check)
        final[track] = {'video': str(job / 'presentation.mp4'), 'sha256': check['video_sha256'], 'metadata': media, 'captions': len(timeline['captions']), 'highlight_windows': timeline['highlight_count'], 'reviewed_frames': frame_rows}
    pt.write(pt.ROOT / 'checks/delivery-check.json', {'all_passed': True, 'reviews': reviews, 'videos': final, 'reference_method': 'Qwen3-TTS reference-based ICL; not fine-tuning'})
    print(json.dumps({track: {k: v for k, v in row.items() if k != 'reviewed_frames'} for track, row in final.items()}, ensure_ascii=False))

if __name__ == '__main__':
    main()
