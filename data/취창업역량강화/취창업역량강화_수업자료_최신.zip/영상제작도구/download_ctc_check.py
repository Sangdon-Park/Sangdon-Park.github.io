"""Download a pinned, safetensors-only Korean CTC model for an independent check."""
import json, os
from pathlib import Path
import download_models as dm
from huggingface_hub import HfApi, hf_hub_download

repo='kresnik/wav2vec2-large-xlsr-korean'
revision='629c9a3501c10ba128bf3fa1eebb12af3be03f61'
destination=Path('C:/Users/HP-SERVER/.cache/career-tts/models/korean-ctc')
allowed={'README.md','config.json','model.safetensors','preprocessor_config.json','special_tokens_map.config','tokenizer_config.json','vocab.json'}
info=HfApi().model_info(repo,revision=revision,files_metadata=True)
for item in info.siblings:
    if item.rfilename not in allowed:continue
    if item.lfs and item.lfs.size>100*1024*1024:
        dm.large_file(repo,revision,item,destination)
    else:
        hf_hub_download(repo,item.rfilename,revision=revision,local_dir=destination)
result={'repo':repo,'revision':revision,'path':str(destination),'weight_sha256':dm.digest(destination/'model.safetensors'),'purpose':'Independent CTC decoding without a language-model decoder for final Korean syllables'}
(dm.R/'checks/korean-ctc-model.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
config=json.loads((dm.R/'config.json').read_text(encoding='utf-8'));config['ctc_model']=str(destination)
(dm.R/'config.json').write_text(json.dumps(config,ensure_ascii=False,indent=2),encoding='utf-8')
lock=json.loads((dm.R/'models.lock.json').read_text(encoding='utf-8'));lock[repo]=revision
(dm.R/'models.lock.json').write_text(json.dumps(lock,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result),flush=True)
