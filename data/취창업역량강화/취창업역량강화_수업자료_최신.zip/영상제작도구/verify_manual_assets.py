"""Check source notes, Korean pronunciation text, and lossless raw preservation."""
import re, json
import numpy as np
import soundfile as sf
import presentation_tts as pt

def run():
    cfg = pt.cfg()
    cfg['video_fps'] = 30
    pt.write(pt.ROOT / 'config.json', cfg)
    lock = pt.read(pt.ROOT / 'models.lock.json')
    lock['funasr/campplus'] = pt.read(pt.ROOT / 'checks/campplus-model.json')['model_revision']
    pt.write(pt.ROOT / 'models.lock.json', lock)
    rows, residual, source_trailers = [], [], 0
    for track in ['lecture', 'portfolio']:
        for row in pt.records(track):
            original = (pt.ROOT / 'notes_orig' / track / f"slide_{row['number']:02d}.txt").read_text(encoding='utf-8-sig')
            if '[출처 / 읽지 않음]' in original:
                source_trailers += 1
            body = original.split('[출처 / 읽지 않음]')[0]
            current = ' '.join(s['caption'] for s in row['segments'])
            same = re.sub(r'\s+', '', body) == re.sub(r'\s+', '', current)
            if not same:
                raise ValueError(f"원고 불일치: {track}/{row['number']}")
            for j, seg in enumerate(row['segments'], 1):
                symbols = re.findall(r'[A-Za-z0-9_=<>%$^{}\\]|[+*/|~]', seg['speech'])
                if symbols:
                    residual.append({'track': track, 'slide': row['number'], 'segment': j, 'symbols': symbols})
            rows.append({'track': track, 'number': row['number'], 'source_matches': same})
    if residual:
        raise ValueError(f'발화 원고에 치환되지 않은 문자: {residual}')
    pt.write(pt.ROOT / 'checks/notes-source-check.json', {'slides_checked': len(rows), 'nonspoken_source_trailers_preserved': source_trailers, 'unconverted_symbol_count': 0, 'source_body_matches': True, 'rows': rows})
    preservation = []
    for track in ['lecture', 'portfolio']:
        job = pt.ROOT / 'output' / track
        for raw in sorted((job / 'raw_segments').glob('*.wav')):
            a, ar = sf.read(raw, dtype='int16')
            b, br = sf.read(job / 'segments' / raw.name, dtype='int16')
            same = ar == br and len(b) >= len(a) and np.array_equal(a, b[:len(a)])
            if not same:
                raise ValueError(f'원본 샘플 변경: {track}/{raw.name}')
            metadata=pt.read(job/'segments'/raw.with_suffix('.json').name)
            protection=metadata['continuation_protection']
            generation=job/protection['full_generation_file']
            g,gr=sf.read(generation,dtype='int16')
            cut=protection['cut_sample']
            assert gr==br and np.array_equal(g[:cut],b[:cut]),'본문 발화가 변경되었습니다.'
            assert pt.filehash(generation)==protection['full_generation_sha256']
            assert protection['cut_gap']['end']-protection['cut_gap']['start']>=.075
            preservation.append({'track': track, 'file': raw.name, 'raw_samples': len(a), 'protected_samples': len(b), 'prefix_bit_exact': True, 'full_generation_file':str(generation),'full_generation_samples':len(g),'wanted_speech_prefix_samples':cut,'wanted_speech_prefix_bit_exact':True})
    pt.write(pt.ROOT / 'checks/raw-preservation.json', {'count': len(preservation), 'all_wanted_speech_pcm_prefixes_bit_exact': True,'full_marker_generations_preserved':True,'rows': preservation})
    print(json.dumps({'notes_checked': len(rows), 'symbols_remaining': len(residual), 'raw_segments_bit_exact': len(preservation)}, ensure_ascii=False))

if __name__ == '__main__':
    run()
