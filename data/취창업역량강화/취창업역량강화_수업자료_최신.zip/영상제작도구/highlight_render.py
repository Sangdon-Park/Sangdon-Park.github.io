"""Render measured sentence cues, resumable slide clips and one continuous audio track.

No ASR timestamp is ever used to cut audio. Source slide geometry is transformed
to the displayed image before the 12-pixel focus margin is added.
"""
import argparse, concurrent.futures, csv, math, re, shutil
from pathlib import Path
import numpy as np
import soundfile as sf
from PIL import Image
import presentation_tts as pt

VERSION = 'sentence-highlight-2026-09-06-v1'
FPS = 30
ASS_HEADER = '''[Script Info]
ScriptType: v4.00+
PlayResX: 1920
PlayResY: 1080
WrapStyle: 2
[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Narration,Malgun Gothic,34,&H00FFFFFF,&H00FFFFFF,&H0017262F,&H0017262F,0,0,0,0,100,100,0,0,1,1,0,2,65,65,27,1
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
'''

def ass_write(path, caps):
    events = []
    for cap in caps:
        text = cap['text'].replace('\\', '\\\\').replace('{', '\\{').replace('}', '\\}').replace('\n', '\\N')
        events.append(f"Dialogue: 0,{pt.timestamp(cap['start'], True)},{pt.timestamp(cap['end'], True)},Narration,,0,0,0,,{text}")
    path.write_text(ASS_HEADER + '\n'.join(events) + '\n', encoding='utf-8-sig')

def integrity(path, expected_frames):
    result = pt.execute([pt.ffmpeg(), '-v', 'error', '-threads', '2', '-i', str(path), '-progress', 'pipe:1', '-nostats', '-f', 'null', '-'])
    if result.stderr.strip():
        raise RuntimeError(f'영상 무결성 검사 실패: {path}\n{result.stderr}')
    frames = re.findall(r'^frame=(\d+)', result.stdout, re.M)
    if not frames or int(frames[-1]) != expected_frames:
        raise RuntimeError(f'프레임 수 불일치: {path}: {frames[-1:]}, expected {expected_frames}')
    return {'decoded_without_error': True, 'decoded_frames': int(frames[-1])}

def prepare(track):
    job = pt.ROOT / 'output' / track
    data = pt.read(job / 'timing.json')
    progress = pt.read(job / 'synthesis-progress.json')
    if not progress.get('complete'):
        raise ValueError('새 음성 합성이 진행 중입니다. 미완성 상태에서 영상을 조립하지 않습니다.')
    if not data.get('complete') or not data.get('is_user_voice'):
        raise ValueError('등록된 목소리의 전체 음성 합성이 필요합니다.')
    if data['voice_hash'] != pt.voice(pt.cfg())['hash']:
        raise ValueError('등록 목소리가 변경되었습니다. 먼저 다시 합성하세요.')
    expected = pt.records(track)
    if len(expected) != len(data['slides']):
        raise ValueError('현재 원고와 음성의 화면 수가 다릅니다.')
    root = job / 'highlight'
    root.mkdir(exist_ok=True)
    fonts = root / 'fonts'
    fonts.mkdir(exist_ok=True)
    shutil.copy2('C:/Windows/Fonts/malgun.ttf', fonts / 'malgun.ttf')
    cfg = pt.cfg()
    slides, allcaps, chapters = [], [], []
    global_sample = 0
    rate = int(cfg['sample_rate'])
    if rate % FPS:
        raise ValueError('샘플레이트는 영상 FPS의 배수여야 합니다.')
    samples_per_frame = rate // FPS
    for src, row in zip(expected, data['slides']):
        if [(s['speech'], s['caption']) for s in src['segments']] != [(s['speech'], s['caption']) for s in row['segments']]:
            raise ValueError(f"원고 변경 후 합성되지 않은 화면: {row['number']}")
        number = row['number']
        folder = root / f'slide_{number:02d}'
        folder.mkdir(exist_ok=True)
        native = pt.ROOT / 'assets_native' / track / f'slide_{number:02d}.png'
        source = native if native.is_file() else pt.ROOT / row['image']
        design = pt.read(pt.ROOT / 'highlights' / 'designs' / track / f'slide_{number:02d}.json')
        sw, sh = design['source_size']
        image = Image.open(source).convert('RGB')
        factor = min(1706 / image.width, 960 / image.height)
        dw, dh = round(image.width * factor), round(image.height * factor)
        left, top = (1920 - dw) // 2, (960 - dh) // 2
        base = Image.new('RGB', (1920, 1080), 'white')
        base.paste(image.resize((dw, dh), Image.Resampling.LANCZOS), (left, top))
        base.paste((23, 38, 47), (0, 960, 1920, 1080))
        base.save(folder / 'base.png')
        focus = {w['sentence_id']: w for w in design['windows']}
        unlit = {w['sentence_id'] for w in design['unhighlighted']}
        if set(focus) & unlit:
            raise ValueError('강조/비강조 중복')
        samples, cursor, caps, windows, ids = [], 0, [], [], []
        for j, segment in enumerate(row['segments'], 1):
            wav, sr = sf.read(job / segment['file'], dtype='float32')
            if sr != rate or wav.ndim != 1:
                raise ValueError('모노 음성 샘플레이트 불일치')
            if 'sentences' not in segment:
                raise ValueError('align_and_check.py 실행이 먼저 필요합니다.')
            for sentence in segment['sentences']:
                sid = f"{j}.{sentence['sentence']}"
                ids.append(sid)
                begin = cursor / rate + sentence['start']
                end = min((cursor + len(wav)) / rate, cursor / rate + sentence['end'])
                if not begin < end:
                    raise ValueError(f'문장 시간 오류 {number}/{sid}')
                caption_lines = pt.wrap_caption(sentence['caption'], 44).splitlines()
                blocks = ['\n'.join(caption_lines[k:k + 2]) for k in range(0, len(caption_lines), 2)]
                length = sum(map(len, blocks))
                offset = begin
                for b, block in enumerate(blocks):
                    finish = end if b == len(blocks) - 1 else offset + (end - begin) * len(block) / length
                    text = block
                    if len(text.splitlines()) > 2:
                        raise ValueError(f'자막 2줄 초과 {number}/{sid}: {text}')
                    caps.append({'start': offset, 'end': finish, 'text': text, 'slide': number, 'sentence_id': sid})
                    offset = finish
                if sid in focus:
                    f = focus[sid]
                    x, y, w, h = f['rect']
                    vertical_margin = 4 if track == 'portfolio' else 12
                    x1 = max(0, round(left + x * dw / sw) - 12)
                    y1 = max(0, round(top + y * dh / sh) - vertical_margin)
                    x2 = min(1920, round(left + (x + w) * dw / sw) + 12)
                    y2 = min(960, round(top + (y + h) * dh / sh) + vertical_margin)
                    windows.append({'sentence_id': sid, 'start': begin, 'end': end, 'rect': [x1, y1, x2 - x1, y2 - y1], 'reason': f['reason'], 'caption': sentence['caption']})
            samples.append(wav)
            cursor += len(wav)
            if j < len(row['segments']):
                gap = np.zeros(round(rate * cfg['segment_gap']), dtype=np.float32)
                samples.append(gap)
                cursor += len(gap)
        if set(ids) != set(focus) | unlit:
            raise ValueError(f'문장 디자인 누락/초과: {number}: {set(ids) ^ (set(focus) | unlit)}')
        gap = round(rate * cfg['slide_gap'])
        total_frames = math.ceil((cursor + gap) / samples_per_frame)
        total_samples = total_frames * samples_per_frame
        samples.append(np.zeros(total_samples - cursor, dtype=np.float32))
        sf.write(folder / 'audio.wav', np.concatenate(samples), rate, subtype='PCM_16')
        windows.sort(key=lambda x: x['start'])
        for a, b in zip(windows, windows[1:]):
            if a['end'] > b['start'] + 1e-6:
                raise ValueError('강조 시간 중첩')
        for w in windows:
            assert 0 <= w['start'] < w['end'] <= total_samples / rate
        ass_write(folder / 'captions.ass', caps)
        pt.write(folder / 'windows.json', {'track': track, 'number': number, 'canvas': [1920, 1080], 'margin_pixels': {'horizontal': 12, 'vertical': 4 if track == 'portfolio' else 12}, 'windows': windows, 'unhighlighted': design['unhighlighted']})
        filters = []
        for win in windows:
            x, y, w, h = win['rect']
            enable = f"gte(t,{win['start']:.6f})*lt(t,{win['end']:.6f})"
            boxes = [(0, 0, 1920, y), (0, y + h, 1920, 960 - y - h), (0, y, x, h), (x + w, y, 1920 - x - w, h)]
            for bx, by, bw, bh in boxes:
                if bw > 0 and bh > 0:
                    filters.append(f"drawbox=x={bx}:y={by}:w={bw}:h={bh}:color=black@0.28:t=fill:enable='{enable}'")
            filters.append(f"drawbox=x={x}:y={y}:w={w}:h={h}:color=0xf5bd25:t=5:enable='{enable}'")
        filters.append('subtitles=captions.ass:fontsdir=../fonts')
        filtertext = ','.join(filters)
        (folder / 'filters.txt').write_text(filtertext, encoding='utf-8')
        key = pt.digest(VERSION, pt.filehash(source), design, caps, windows, total_frames)
        slides.append({'number': number, 'title': row['title'], 'folder': str(folder), 'frames': total_frames, 'seconds': total_samples / rate, 'key': key, 'windows': windows})
        offset = global_sample / rate
        allcaps.extend({**c, 'start': c['start'] + offset, 'end': c['end'] + offset} for c in caps)
        chapters.append({'number': number, 'title': row['title'], 'start': offset, 'end': offset + total_samples / rate, 'image': str(source)})
        global_sample += total_samples
    with sf.SoundFile(job / 'narration.wav', 'w', samplerate=rate, channels=1, subtype='PCM_16') as dst:
        for slide in slides:
            wav, sr = sf.read(Path(slide['folder']) / 'audio.wav', dtype='float32')
            dst.write(wav)
    pt.normalize_narration(job)
    lines = []
    for i, cap in enumerate(allcaps, 1):
        lines.extend([str(i), f"{pt.timestamp(cap['start'])} --> {pt.timestamp(cap['end'])}", cap['text'], ''])
    (job / 'captions.srt').write_text('\n'.join(lines), encoding='utf-8')
    ass_write(job / 'timeline.ass', allcaps)
    with open(job / 'chapters.csv', 'w', encoding='utf-8-sig', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=['number', 'title', 'start', 'end', 'image'])
        writer.writeheader()
        writer.writerows(chapters)
    timeline = {'seconds': global_sample / rate, 'frames': global_sample // samples_per_frame, 'fps': FPS, 'caption_timing': 'ASR word alignment to preserved script; never used to cut audio', 'chapters': chapters, 'captions': allcaps, 'slide_count': len(slides), 'highlight_count': sum(len(s['windows']) for s in slides)}
    pt.write(job / 'timeline.json', timeline)
    pt.write(root / 'render-plan.json', {'renderer': VERSION, 'track': track, 'slides': slides, 'timeline': {k: v for k, v in timeline.items() if k not in ['captions', 'chapters']}})
    return job, slides, timeline

def render_slide(slide):
    folder = Path(slide['folder'])
    clip, receipt = folder / 'clip.mp4', folder / 'render-check.json'
    if clip.is_file() and receipt.is_file() and pt.read(receipt).get('key') == slide['key'] and pt.read(receipt).get('sha256') == pt.filehash(clip):
        print(f"슬라이드 {slide['number']:02d}: 검증된 캐시 사용", flush=True)
        return
    temp = folder / 'clip.new.mp4'
    pt.execute([pt.ffmpeg(), '-y', '-v', 'warning', '-loop', '1', '-framerate', str(FPS), '-i', 'base.png', '-filter_script:v', 'filters.txt', '-filter_threads', '1', '-frames:v', str(slide['frames']), '-an', '-c:v', 'libx264', '-threads', '2', '-preset', 'veryfast', '-tune', 'stillimage', '-crf', '20', '-pix_fmt', 'yuv420p', '-movflags', '+faststart', temp.name], cwd=folder)
    check = integrity(temp, slide['frames'])
    temp.replace(clip)
    pt.write(receipt, {**check, 'key': slide['key'], 'sha256': pt.filehash(clip), 'seconds': slide['seconds'], 'fps': FPS, 'canvas': [1920, 1080], 'highlight_count': len(slide['windows'])})
    print(f"슬라이드 {slide['number']:02d}: {slide['seconds']:.1f}초 렌더·전체 디코딩 통과", flush=True)

def review_frames(slides):
    for slide in slides:
        folder = Path(slide['folder'])
        frame_dir = folder.parent / 'frames' / folder.name
        frame_dir.mkdir(parents=True, exist_ok=True)
        windows = [{'start': 0, 'end': 0, 'sentence_id': 'plain', 'rect': None}] + slide['windows']
        index = []
        for i, window in enumerate(windows):
            time = (window['start'] + window['end']) / 2
            name = f'frame_{i:02d}.png'
            path = frame_dir / name
            # Each frame is extracted from the completed clip, including burned-in captions.
            pt.execute([pt.ffmpeg(), '-y', '-v', 'error', '-ss', f'{time:.6f}', '-i', str(folder / 'clip.mp4'), '-frames:v', '1', '-threads', '1', str(path)])
            index.append({'file': str(path), 'seconds': time, **window})
        pt.write(frame_dir / 'index.json', {'number': slide['number'], 'frames': index})

def render(track, workers=3, frames=True):
    if shutil.disk_usage(pt.ROOT).free < 3 * 1024**3:
        raise RuntimeError('영상 생성에 필요한 여유 공간 3GB가 없습니다.')
    job, slides, timeline = prepare(track)
    print(f"{track}: {len(slides)}개 화면, {timeline['seconds']/60:.2f}분, 강조 {timeline['highlight_count']}개", flush=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        list(pool.map(render_slide, slides))
    concat = job / 'highlight' / 'concat.txt'
    concat.write_text('\n'.join(f"file 'slide_{s['number']:02d}/clip.mp4'" for s in slides) + '\n', encoding='utf-8')
    temp = job / 'presentation.new.mp4'
    pt.execute([pt.ffmpeg(), '-y', '-v', 'warning', '-f', 'concat', '-safe', '0', '-i', str(concat), '-i', str(job / 'narration.wav'), '-map', '0:v:0', '-map', '1:a:0', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart', str(temp)])
    check = integrity(temp, timeline['frames'])
    temp.replace(job / 'presentation.mp4')
    pt.write(job / 'render-check.json', {**check, 'renderer': VERSION, 'audio_seconds': timeline['seconds'], 'slide_count': len(slides), 'video_bytes': (job / 'presentation.mp4').stat().st_size, 'video_sha256': pt.filehash(job / 'presentation.mp4'), 'is_user_voice': True, 'fps': FPS, 'canvas': [1920, 1080], 'highlight_count': timeline['highlight_count'], 'continuous_audio_encoded_once': True, 'video_concat_stream_copy': True, 'visual_review_status': 'pending'})
    print(f"완성 영상: {job / 'presentation.mp4'}", flush=True)
    if frames:
        review_frames(slides)
        print(f'실제 영상 검수 프레임 저장 완료: {track}', flush=True)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--track', required=True, choices=['lecture', 'portfolio'])
    parser.add_argument('--workers', type=int, default=3)
    parser.add_argument('--skip-frames', action='store_true')
    args = parser.parse_args()
    render(args.track, args.workers, not args.skip_frames)
