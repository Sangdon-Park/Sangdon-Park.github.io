"""Record exactly what was regenerated, protected, and checked."""
from datetime import datetime, timezone
import presentation_tts as pt

POLICY = 'protected-ending-gratitude-silence-v2'


def main():
    comparison = pt.ROOT / 'checks/ending-repair-pilot/lecture_01_02.before-after.wav'
    feedback = {
        'comparison_file': str(comparison),
        'comparison_sha256': pt.filehash(comparison),
        'question': '뒤쪽 “정리하겠습니다”의 마지막 ‘다’는 온전하게 들리나요?',
        'user_answer': '뒤쪽은 어미가 온전함',
        'scope': 'The user listened to this before/after comparison, not every final paragraph.',
        'approved_generation_method': POLICY,
    }
    pt.write(pt.ROOT / 'checks/ending-repair-user-feedback.json', feedback)
    rows, tracks = [], {}
    for track in ['lecture', 'portfolio']:
        job = pt.ROOT / 'output' / track
        progress = pt.read(job / 'synthesis-progress.json')
        assert progress['complete'] and progress['ending_policy'] == POLICY
        expected_count = sum(len(s['segments']) for s in pt.records(track))
        files = sorted((job / 'segments').glob('*.json'))
        assert len(files) == expected_count
        rejected = [pt.read(p) for p in (job / 'generation_attempts').glob('*.json') if pt.read(p).get('accepted') is False]
        for file in files:
            meta = pt.read(file)
            protection = meta['continuation_protection']
            assert protection['policy'] == POLICY
            gap = protection['cut_gap']['end'] - protection['cut_gap']['start']
            assert gap >= .075
            assert not protection['speech_fade_applied']
            assert not protection['cut_directly_at_asr_timestamp']
            raw = job / protection['full_generation_file']
            assert pt.filehash(raw) == protection['full_generation_sha256']
            before = pt.ROOT / 'audio_old/before-ending-generation-v2' / track / 'segments' / file.name
            assert pt.read(before)['key'] != meta['key'], 'An old segment has not been regenerated.'
            rows.append({'track': track, 'segment': file.stem, 'key': meta['key'], 'quiet_gap_seconds': gap,
                         'full_generation_sha256': pt.filehash(raw), 'final_wave_sha256': pt.filehash(file.with_suffix('.wav')),
                         'accepted_attempt': meta['generation_attempt']})
        tracks[track] = {'regenerated_paragraphs': len(files), 'rejected_ambiguous_generations': len(rejected),
                         'content_review_pending': pt.read(job / 'ending-check.json')['review_count']}
    preservation = pt.read(pt.ROOT / 'checks/raw-preservation.json')
    assert preservation['count'] == len(rows) == 150
    assert preservation['all_wanted_speech_pcm_prefixes_bit_exact']
    assert all(t['content_review_pending'] == 0 for t in tracks.values())
    summary = {'recorded_at_utc': datetime.now(timezone.utc).isoformat(), 'policy': POLICY,
               'regenerated_paragraphs': len(rows), 'tracks': tracks,
               'minimum_selected_quiet_gap_seconds': min(r['quiet_gap_seconds'] for r in rows),
               'full_generations_retained': True, 'wanted_speech_preserved_bit_exact': True,
               'user_feedback': feedback,
               'recognition_limit': 'Whisper and the independent CTC pilot recognized complete endings even in the known defective old sample. ASR agreement is not proof of an audible final syllable.',
               'scope_of_verification': 'User-approved pilot method applied to every paragraph; individual acoustic gap checks and exact PCM-prefix verification, content diagnostics, plus final media decoding and separate visual review. No claim that every paragraph was heard by the user.',
               'segments': rows}
    pt.write(pt.ROOT / 'checks/ending-repair-summary.json', summary)
    print({k: v for k, v in summary.items() if k not in ['segments', 'user_feedback']})


if __name__ == '__main__':
    main()
