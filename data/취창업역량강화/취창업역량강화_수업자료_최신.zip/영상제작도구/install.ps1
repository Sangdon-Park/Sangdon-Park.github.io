﻿$ErrorActionPreference='Stop'
$taskConfig=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'config.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if(-not (Test-Path -LiteralPath $taskConfig.python)){
  throw '현재 PC의 준비된 Python 환경을 찾을 수 없습니다. config.json의 python 경로를 확인하세요.'
}
uv pip install --python $taskConfig.python torch==2.8.0 torchaudio==2.8.0 --index-url https://download.pytorch.org/whl/cu128
if($LASTEXITCODE -ne 0){exit $LASTEXITCODE}
uv pip install --python $taskConfig.python --extra-index-url https://download.pytorch.org/whl/cu128 -r (Join-Path $PSScriptRoot 'requirements.lock.txt')
if($LASTEXITCODE -ne 0){exit $LASTEXITCODE}
& $taskConfig.python -X utf8 (Join-Path $PSScriptRoot 'download_models.py')
exit $LASTEXITCODE
