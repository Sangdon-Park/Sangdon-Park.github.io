﻿param(
  [ValidateSet('doctor','register','import-voice','sample','synthesize','render','all')][string]$Command='doctor',
  [ValidateSet('lecture','portfolio')][string]$Track='lecture',
  [string]$InputAudio,
  [string]$TranscriptFile
)
$ErrorActionPreference='Stop'
$taskConfig=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'config.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$taskArgs=@('-X','utf8',(Join-Path $PSScriptRoot 'presentation_tts.py'),$Command,'--track',$Track)
if($InputAudio){$taskArgs+=@('--audio',$InputAudio)}
if($TranscriptFile){$taskArgs+=@('--transcript',$TranscriptFile)}
& $taskConfig.python @taskArgs
exit $LASTEXITCODE
