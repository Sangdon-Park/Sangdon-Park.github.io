"""CAM++ comparison against the explicitly registered local voice recording."""
from pathlib import Path
import json,sys,math,argparse
import numpy as np,soundfile as sf,torch
import torchaudio.compliance.kaldi as kaldi
from scipy.signal import resample_poly
import presentation_tts as pt
sys.path.insert(0,str(pt.ROOT/'vendor'))
from speakerlab.models.campplus.DTDNN import CAMPPlus

class Verifier:
 def __init__(self):
  torch.set_num_threads(4)
  self.model=CAMPPlus(feat_dim=80,embedding_size=192).eval()
  weights=torch.load(Path(pt.cfg()['speaker_model'])/'campplus_cn_common.bin',map_location='cpu',weights_only=True)
  self.model.load_state_dict(weights,strict=True)
 def embedding(self,a,sr):
  if a.ndim>1:a=a.mean(axis=1)
  if sr!=16000:
   g=math.gcd(sr,16000);a=resample_poly(a,16000//g,sr//g)
  x=torch.from_numpy(np.asarray(a,dtype=np.float32)).unsqueeze(0)
  f=kaldi.fbank(x,num_mel_bins=80,sample_frequency=16000,dither=0)
  f=f-f.mean(0,keepdim=True)
  with torch.inference_mode():v=self.model(f.unsqueeze(0)).squeeze().numpy()
  return v/max(np.linalg.norm(v),1e-12)
 def file(self,p,max_seconds=10):
  a,sr=sf.read(p,dtype='float32')
  return self.embedding(a[:int(sr*max_seconds)],sr)

def run(track):
 K=pt.ROOT;V=Verifier();ref=V.file(K/pt.cfg()['reference_audio'],16)
 originals=[]
 if (K/'checks/user-recording/recording-16k.wav').exists():
  source,sr=sf.read(K/'checks/user-recording/recording-16k.wav',dtype='float32')
  for start in [20,30,40,50]:
   emb=V.embedding(source[int(start*sr):int((start+8)*sr)],sr);originals.append(float(ref@emb))
 example=K/'checks/example-voice/official-reference.wav'
 control=float(ref@V.file(example)) if example.exists() else None
 rows=[];job=K/'output'/track;cache=job/'speaker';cache.mkdir(exist_ok=True)
 for p in sorted((job/'segments').glob('*.wav')):
  if p.stem.endswith('.new'):continue
  key=pt.digest(pt.filehash(p),pt.filehash(K/pt.cfg()['reference_audio']),'campplus-cn-common-v1')
  receipt=cache/(p.stem+'.json')
  if receipt.exists() and pt.read(receipt).get('key')==key:row=pt.read(receipt)
  else:
   cosine=float(ref@V.file(p));row={'key':key,'file':p.name,'cosine':cosine};pt.write(receipt,row)
  rows.append(row)
 summary={'track':track,'model':'funasr/campplus common 192D','same_recording_other_windows_cosine':originals,'official_example_control_cosine':control,'generated_segments':len(rows),'generated_min':min(r['cosine'] for r in rows),'generated_mean':float(np.mean([r['cosine'] for r in rows])),'generated_max':max(r['cosine'] for r in rows),'interpretation':'Relative diagnostic, not identity proof or a guarantee of perceived similarity; thresholds from another recording are not universal.','segments':rows}
 pt.write(job/'speaker-check.json',summary);print(json.dumps({k:v for k,v in summary.items() if k!='segments'},ensure_ascii=False),flush=True)
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--track',choices=['lecture','portfolio','lecture-sample'],required=True);run(a.parse_args().track)
