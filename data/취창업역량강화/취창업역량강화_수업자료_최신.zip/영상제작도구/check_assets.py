from pathlib import Path
import json,re
R=Path(__file__).parent;D=json.loads((R/'manifest.json').read_text(encoding='utf-8'))
report={}
for track,count in [('lecture',36),('portfolio',8)]:
 rows=D['tracks'][track]
 assert len(rows)==count
 assert [r['number'] for r in rows]==list(range(1,count+1))
 assert all((R/r['image']).is_file() for r in rows)
 assert all(s['speech'].strip() and s['caption'].strip() for r in rows for s in r['segments'])
 assert all('[출처' not in s['speech'] and 'http://' not in s['speech'] and 'https://' not in s['speech'] for r in rows for s in r['segments'])
 report[track]={'slides':count,'segments':sum(len(r['segments']) for r in rows),'speech_chars':sum(len(s['speech']) for r in rows for s in r['segments']),'longest_segment':max(len(s['speech']) for r in rows for s in r['segments'])}
(R/'checks'/'assets.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
