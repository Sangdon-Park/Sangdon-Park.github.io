from pathlib import Path
R=Path(__file__).parent
commands={'00_목소리_등록.cmd':'register','01_환경확인.cmd':'doctor','02_목소리_샘플합성.cmd':'sample --track lecture','03_발표영상_만들기.cmd':'all --track lecture','04_포트폴리오영상_만들기.cmd':'all --track portfolio'}
for name,command in commands.items():
 text='@echo off\r\npushd "%~dp0"\r\npowershell.exe -NoProfile -Command "$taskConfig = Get-Content -LiteralPath \'config.json\' -Raw | ConvertFrom-Json; & $taskConfig.python -X utf8 presentation_tts.py '+command+'; exit $LASTEXITCODE"\r\nset "taskCode=%ERRORLEVEL%"\r\necho.\r\npause\r\npopd\r\nexit /b %taskCode%\r\n'
 (R/name).write_bytes(text.encode('ascii'))
print(f'Created {len(commands)} launchers')
