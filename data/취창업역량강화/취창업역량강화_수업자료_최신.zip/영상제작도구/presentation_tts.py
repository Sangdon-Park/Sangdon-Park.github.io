"""Local narration and slide video pipeline. Reference audio is always explicit."""
import argparse,csv,hashlib,json,os,re,shutil,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
os.environ.setdefault('HF_HUB_OFFLINE','1')
os.environ.setdefault('TRANSFORMERS_OFFLINE','1')
os.environ.setdefault('HF_HUB_DISABLE_TELEMETRY','1')
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def write(p,d):
 Path(p).parent.mkdir(parents=True,exist_ok=True)
 Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8')
def cfg():return read(ROOT/'config.json')
def digest(*parts):return hashlib.sha256(json.dumps(parts,ensure_ascii=False,sort_keys=True).encode()).hexdigest()
def filehash(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def ffmpeg():
 import imageio_ffmpeg
 return imageio_ffmpeg.get_ffmpeg_exe()
def execute(args,cwd=None):
 r=subprocess.run(args,cwd=cwd,capture_output=True,text=True,encoding='utf-8',errors='replace')
 if r.returncode:raise RuntimeError(r.stderr[-3500:])
 return r
def records(track):return read(ROOT/'manifest.json')['tracks'][track]
def voice(config,required=True):
 a=ROOT/config['reference_audio'];t=ROOT/config['reference_text']
 if not a.is_file() or not t.is_file():
  if required:raise ValueError('목소리가 아직 등록되지 않았습니다. voice/reference.wav와 실제 발화 내용인 reference.txt를 넣어 주세요.')
  return {'ready':False,'reason':'reference audio and transcript are not registered'}
 import soundfile as sf
 info=sf.info(a);transcript=t.read_text(encoding='utf-8-sig').strip()
 if not transcript:raise ValueError('참조 음성 전사 파일이 비어 있습니다.')
 if not 3<=info.duration<=60:raise ValueError(f'참조 구간은 3~60초여야 합니다. 현재 {info.duration:.1f}초입니다. 10~20초의 또렷한 구간을 권장합니다.')
 return {'ready':True,'audio':str(a),'transcript':transcript,'seconds':info.duration,'hash':digest(filehash(a),transcript)}
def doctor():
 config=cfg();import torch
 from importlib.metadata import version
 files=[Path(config['model'])/x for x in ['config.json','model.safetensors','speech_tokenizer/model.safetensors']]
 ff=ffmpeg();filters=execute([ff,'-hide_banner','-filters']).stdout
 model_ok=all(p.is_file() and p.stat().st_size>0 for p in files)
 gpu=torch.cuda.is_available();gpu_test=False
 if gpu:
  a=torch.ones((64,64),device='cuda');gpu_test=bool((a@a)[0,0].item()==64)
 result={'model_downloaded':model_ok,'model_files':[str(p) for p in files],
  'gpu':torch.cuda.get_device_name(0) if gpu else None,'gpu_compute_ok':gpu_test,
  'torch':torch.__version__,'qwen_tts':version('qwen-tts'),'ffmpeg':ff,'subtitle_filter_available':' subtitles ' in filters,
  'asr_model_downloaded':(Path(config['asr_model'])/'model.bin').is_file(),
  'speaker_model_downloaded':(Path(config['speaker_model'])/'campplus_cn_common.bin').is_file(),
  'lecture_slides':len(records('lecture')),'portfolio_pages':len(records('portfolio')),'voice':voice(config,False)}
 result['ready_for_voice_registration']=bool(model_ok and gpu_test and result['subtitle_filter_available'])
 result['ready_for_video']=bool(result['ready_for_voice_registration'] and result['asr_model_downloaded'] and result['speaker_model_downloaded'] and result['voice']['ready'])
 write(ROOT/'checks'/'environment.json',result);print(json.dumps(result,ensure_ascii=False,indent=2))
 if not result['ready_for_voice_registration']:raise RuntimeError('필수 환경 검사가 완료되지 않았습니다.')
 return result
def import_voice(audio,transcript):
 text=Path(transcript).read_text(encoding='utf-8-sig').strip()
 if not text:raise ValueError('전사 파일이 비어 있습니다.')
 config=cfg();dst=ROOT/config['reference_audio'];dst.parent.mkdir(exist_ok=True)
 # Decode to a temporary file first; a bad input never replaces a valid reference.
 tmp=dst.with_name('reference.new.wav')
 execute([ffmpeg(),'-y','-i',str(Path(audio).resolve()),'-ac','1','-ar','24000','-c:a','pcm_s16le',str(tmp)])
 import soundfile as sf
 duration=sf.info(tmp).duration
 if not 3<=duration<=60:raise ValueError(f'변환된 녹음은 {duration:.1f}초입니다. 사용할 3~60초 구간을 선택해 주세요. 기존 참조 파일은 유지했습니다.')
 tmp.replace(dst);(ROOT/config['reference_text']).write_text(text,encoding='utf-8')
 print(f'참조 음성 등록 완료: {duration:.1f}초. 새 목소리로 샘플을 합성할 수 있습니다.')
def load_model(config):
 import torch
 from qwen_tts import Qwen3TTSModel
 return Qwen3TTSModel.from_pretrained(config['model'],device_map=config['device'],dtype=torch.bfloat16,attn_implementation=config['attention'],local_files_only=True)
def audio_check(w,sr,speech):
 import numpy as np
 a=np.asarray(w,dtype=np.float32)
 if a.ndim>1:a=a.mean(axis=-1)
 if not np.isfinite(a).all():raise ValueError('합성 음성에 유효하지 않은 값이 있습니다.')
 secs=len(a)/sr;rms=float(np.sqrt(np.mean(a*a)))
 if secs<0.3 or secs>max(90,len(speech)*1.3) or rms<0.0001:raise ValueError(f'비정상 합성 결과: {secs:.2f}초, RMS={rms:.6f}')
 peak=float(np.max(np.abs(a)))
 if peak>0.98:a=a*(0.98/peak)
 return a,{'seconds':secs,'rms':rms,'peak_before_normalization':peak}
def synthesize(track,limit=None):
 import soundfile as sf
 import torch
 import protected_endings as pe
 config=cfg();ref=voice(config);items=records(track)[:limit]
 job=ROOT/'output'/(f'{track}-sample' if limit else track);(job/'segments').mkdir(parents=True,exist_ok=True)
 pending=[];timing=[]
 for row in items:
  for j,seg in enumerate(row['segments'],1):
   stem=f'slide_{row["number"]:02d}_{j:02d}';wav=job/'segments'/f'{stem}.wav';meta=wav.with_suffix('.json')
   key=digest(seg['speech'],ref['hash'],config['model'],config['attention'],pe.VERSION,2400)
   if seg.get('take',0):key=digest(key,'take',int(seg['take']))
   cached=wav.exists() and meta.exists() and read(meta).get('key')==key
   if not cached:
    pending.append({'number':row['number'],'segment':j,'speech':seg['speech'],'key':key,'wav':wav,'meta':meta})
 if pending:
  write(job/'synthesis-progress.json',{'track':track,'complete':False,'completed_new_segments':0,'total_new_segments':len(pending),'ending_policy':pe.VERSION})
  print('로컬 모델을 읽고 참조 음성을 등록합니다.',flush=True)
  model=load_model(config)
  prompt=model.create_voice_clone_prompt(ref_audio=ref['audio'],ref_text=ref['transcript'],x_vector_only_mode=False)
  # Similar lengths reduce padding work in the model's supported batch API.
  pending.sort(key=lambda p:len(p['speech']),reverse=True)
  batch_size=max(1,min(8,int(config.get('batch_size',4))));completed=0
  def generate(batch,attempt=0):
   nonlocal completed
   torch.manual_seed(int(digest([p['key'] for p in batch],attempt)[:8],16));started=time.time()
   try:
    with torch.inference_mode():
     waves,sr=model.generate_voice_clone(text=[pe.generation_text(p['speech']) for p in batch],language='Korean',voice_clone_prompt=prompt,non_streaming_mode=True,max_new_tokens=2400)
   except torch.cuda.OutOfMemoryError:
    torch.cuda.empty_cache()
    if len(batch)==1:raise
    mid=len(batch)//2;generate(batch[:mid],attempt);generate(batch[mid:],attempt);return
   if len(waves)!=len(batch):raise RuntimeError('합성 문단 수와 반환된 음성 수가 다릅니다.')
   elapsed=time.time()-started
   rejected=[]
   for item,wave in zip(batch,waves):
    w,quality=audio_check(wave,sr,item['speech']);wav=item['wav'];tmp=wav.with_suffix('.new.wav')
    raw_dir=job/'generation_attempts';raw_dir.mkdir(exist_ok=True)
    raw=raw_dir/f"{wav.stem}_{item['key'][:10]}_take{attempt}.wav"
    sf.write(raw,w,sr,subtype='PCM_16')
    try:
     w,protection=pe.protect(w,sr,item['speech'])
     protection['full_generation_file']=str(raw.relative_to(job));protection['full_generation_sha256']=filehash(raw)
    except ValueError as error:
     write(raw.with_suffix('.json'),{'key':item['key'],'attempt':attempt,'accepted':False,'reason':str(error)})
     print(f"{wav.stem}: 무음 경계가 명확하지 않아 다시 생성합니다. {error}",flush=True)
     rejected.append(item);continue
    sf.write(tmp,w,sr,subtype='PCM_16');tmp.replace(wav)
    metadata={'key':item['key'],'sample_rate':sr,'quality':quality,'generation_seconds':elapsed/len(batch),'batch_generation_seconds':elapsed,'batch_size':len(batch),'speech':item['speech'],'voice_hash':ref['hash'],'continuation_protection':protection,'generation_attempt':attempt}
    write(item['meta'],metadata);write(raw.with_suffix('.json'),{'key':item['key'],'attempt':attempt,'accepted':True,'protection':protection})
    completed+=1
   write(job/'synthesis-progress.json',{'track':track,'complete':False,'completed_new_segments':completed,'total_new_segments':len(pending),'last_batch_seconds':elapsed,'voice_hash':ref['hash'],'ending_policy':pe.VERSION})
   print(f'{track}: {completed}/{len(pending)}개 문단 합성 완료, 이번 {len(batch)}개 {elapsed:.1f}초',flush=True)
   if rejected:
    if attempt>=5:raise RuntimeError('후속 어절과 본문 사이의 안전한 무음을 확보하지 못했습니다. 원본을 보존했고 문제 문단은 미완료입니다.')
    generate(rejected,attempt+1)
  for start in range(0,len(pending),batch_size):generate(pending[start:start+batch_size])
  del model,prompt;torch.cuda.empty_cache()
 for row in items:
  segments=[]
  for j,seg in enumerate(row['segments'],1):
   wav=job/'segments'/f'slide_{row["number"]:02d}_{j:02d}.wav'
   info=sf.info(wav)
   segments.append({**seg,'file':str(wav.relative_to(job)),'seconds':info.duration,'sample_rate':info.samplerate})
  timing.append({'number':row['number'],'title':row['title'],'image':row['image'],'segments':segments})
 write(job/'timing.json',{'track':track,'voice_hash':ref['hash'],'is_user_voice':True,'complete':len(items)==len(records(track)),'slides':timing})
 write(job/'synthesis-progress.json',{'track':track,'complete':True,'ending_policy':pe.VERSION,'total_segments':sum(len(r['segments']) for r in timing),'voice_hash':ref['hash']})
 print(f'합성 완료: {len(items)}개 화면. {job}',flush=True)
 return job
def timestamp(seconds,ass=False):
 n=int(round(seconds*(100 if ass else 1000)));base=100 if ass else 1000
 whole,frac=divmod(n,base);minutes,s=divmod(whole,60);h,m=divmod(minutes,60)
 return f'{h}:{m:02}:{s:02}.{frac:02}' if ass else f'{h:02}:{m:02}:{s:02},{frac:03}'
def split_caption(t,limit=100):
 words=t.split();blocks=[];cur=''
 for word in words:
  if cur and len(cur)+1+len(word)>limit:blocks.append(cur);cur=word
  else:cur=(cur+' '+word).strip()
 if cur:blocks.append(cur)
 return blocks
def wrap_caption(t,width=50):
 words=t.split();lines=[];cur=''
 for word in words:
  if cur and len(cur)+1+len(word)>width:lines.append(cur);cur=word
  else:cur=(cur+' '+word).strip()
 if cur:lines.append(cur)
 return '\n'.join(lines)

def normalize_narration(job):
 import soundfile as sf
 path=job/'narration.wav';info=sf.info(path)
 probe=execute([ffmpeg(),'-hide_banner','-i',str(path),'-af','loudnorm=I=-18:TP=-1.5:LRA=11:print_format=json','-f','null','-'])
 measured=json.JSONDecoder().raw_decode(probe.stderr[probe.stderr.rfind('{'):])[0]
 parameters=f"loudnorm=I=-18:TP=-1.5:LRA=11:measured_I={measured['input_i']}:measured_TP={measured['input_tp']}:measured_LRA={measured['input_lra']}:measured_thresh={measured['input_thresh']}:offset={measured['target_offset']}:linear=true:print_format=json"
 parameters+=f',aresample={info.samplerate},apad=whole_len={info.frames},atrim=end_sample={info.frames}'
 temporary=job/'narration.normalized.wav'
 output=execute([ffmpeg(),'-y','-hide_banner','-i',str(path),'-af',parameters,'-ar',str(info.samplerate),'-ac','1','-c:a','pcm_s16le',str(temporary)])
 assert sf.info(temporary).frames==info.frames,'음량 조정 중 오디오 길이가 바뀌었습니다.'
 path.replace(job/'narration.raw.wav');temporary.replace(path)
 final=json.JSONDecoder().raw_decode(output.stderr[output.stderr.rfind('{'):])[0]
 write(job/'loudness.json',{'target_lufs':-18,'true_peak_limit_dbtp':-1.5,'original':measured,'normalized':final,'sample_count_preserved':True})
def assemble(job):
 import numpy as np,soundfile as sf
 config=cfg();data=read(job/'timing.json');slides=data['slides'];sample_rates={s['sample_rate'] for r in slides for s in r['segments']}
 if len(sample_rates)!=1:raise ValueError('오디오 샘플레이트가 서로 다릅니다.')
 sr=sample_rates.pop();cursor=0;captions=[];chapters=[]
 with sf.SoundFile(job/'narration.wav','w',samplerate=sr,channels=1,subtype='PCM_16') as dst:
  for i,row in enumerate(slides):
   start=cursor/sr
   for j,seg in enumerate(row['segments']):
    w,actual_sr=sf.read(job/seg['file'],dtype='float32');assert actual_sr==sr
    if w.ndim>1:w=w.mean(axis=-1)
    begin=cursor/sr;dst.write(w);cursor+=len(w);end=cursor/sr
    blocks=split_caption(seg['caption']);total=sum(len(t) for t in blocks);offset=begin
    for k,block in enumerate(blocks):
     next_t=end if k==len(blocks)-1 else offset+(end-begin)*len(block)/total
     captions.append({'start':offset,'end':next_t,'text':wrap_caption(block),'slide':row['number']});offset=next_t
    if j<len(row['segments'])-1:
     gap=np.zeros(round(sr*config['segment_gap']),dtype=np.float32);dst.write(gap);cursor+=len(gap)
   if i<len(slides)-1:
    gap=np.zeros(round(sr*config['slide_gap']),dtype=np.float32);dst.write(gap);cursor+=len(gap)
   chapters.append({'number':row['number'],'title':row['title'],'image':row['image'],'start':start,'end':cursor/sr})
 normalize_narration(job)
 srt=[];events=[]
 for i,cap in enumerate(captions,1):
  srt.extend([str(i),f'{timestamp(cap["start"])} --> {timestamp(cap["end"])}',cap['text'],''])
  txt=cap['text'].replace('\\','\\\\').replace('{','\\{').replace('}','\\}').replace('\n','\\N')
  events.append(f'Dialogue: 0,{timestamp(cap["start"],True)},{timestamp(cap["end"],True)},Narration,,0,0,0,,{txt}')
 (job/'captions.srt').write_text('\n'.join(srt),encoding='utf-8')
 header='''[Script Info]
ScriptType: v4.00+
PlayResX: 1920
PlayResY: 1080
WrapStyle: 0
[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Narration,Malgun Gothic,34,&H00FFFFFF,&H00FFFFFF,&H0017262F,&H0017262F,0,0,0,0,100,100,0,0,1,1,0,2,60,60,17,1
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
'''
 (job/'timeline.ass').write_text(header+'\n'.join(events)+'\n',encoding='utf-8-sig')
 with open(job/'chapters.csv','w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=['number','title','start','end','image']);w.writeheader();w.writerows(chapters)
 write(job/'timeline.json',{'seconds':cursor/sr,'caption_timing':'measured segment duration; long captions subdivided proportionally','chapters':chapters,'captions':captions})
 return chapters,cursor/sr
def render_plain(job):
 data=read(job/'timing.json')
 if data.get('is_user_voice') and not data.get('complete'):raise ValueError('전체 영상은 모든 슬라이드 음성 합성이 끝난 뒤 생성합니다. 현재는 샘플입니다.')
 if data.get('is_user_voice'):
  expected=records(data['track'])
  if data.get('voice_hash')!=voice(cfg())['hash']:raise ValueError('등록한 목소리가 바뀌었습니다. all 명령으로 다시 합성해 주세요.')
  if len(expected)!=len(data['slides']):raise ValueError('화면 수가 바뀌었습니다. all 명령으로 다시 합성해 주세요.')
  for src,done in zip(expected,data['slides']):
   a=[(s['speech'],s['caption']) for s in src['segments']]
   b=[(s['speech'],s['caption']) for s in done['segments']]
   if src['number']!=done['number'] or src['image']!=done['image'] or a!=b:raise ValueError('원고 또는 화면 연결이 바뀌었습니다. all 명령으로 다시 합성해 주세요.')
 chapters,total=assemble(job);(job/'slides').mkdir(exist_ok=True);lines=[]
 for ch in chapters:
  filename=f'slide_{ch["number"]:02d}.png';shutil.copy2(ROOT/ch['image'],job/'slides'/filename)
  lines.extend([f"file 'slides/{filename}'",'option framerate 1000',f'duration {ch["end"]-ch["start"]:.6f}'])
 lines.extend([f"file 'slides/slide_{chapters[-1]['number']:02d}.png'",'option framerate 1000'])
 (job/'images.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
 fonts=job/'fonts';fonts.mkdir(exist_ok=True)
 shutil.copy2('C:/Windows/Fonts/malgun.ttf',fonts/'malgun.ttf')
 filters='scale=1706:960:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:0:color=white,drawbox=x=0:y=960:w=iw:h=120:color=0x17262f:t=fill,subtitles=timeline.ass:fontsdir=fonts'
 if not data.get('is_user_voice'):
  # An explicit banner is added for installation-test video only.
  filters+=",drawtext=fontfile=fonts/malgun.ttf:text='설치 검사 예제 음성 - 교수님 목소리 아님':fontsize=32:fontcolor=white:box=1:boxcolor=0x17262f@0.9:x=30:y=15"
 args=[ffmpeg(),'-y','-f','concat','-safe','0','-i','images.txt','-i','narration.wav','-vf',filters,'-r','24','-c:v','libx264','-preset','fast','-tune','stillimage','-crf','20','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k','-t',f'{total:.6f}','-movflags','+faststart','presentation.mp4']
 print(f'영상 생성 중: {len(chapters)}개 화면, {total/60:.1f}분',flush=True)
 execute(args,cwd=job)
 execute([ffmpeg(),'-v','error','-i',str(job/'presentation.mp4'),'-f','null','-'])
 write(job/'render-check.json',{'decoded_without_error':True,'audio_seconds':total,'slide_count':len(chapters),'video_bytes':(job/'presentation.mp4').stat().st_size,'is_user_voice':data.get('is_user_voice',False)})
 print(f'영상 완료: {job/"presentation.mp4"}',flush=True)

def render(job):
 data=read(job/'timing.json')
 if not data.get('is_user_voice'):
  return render_plain(job)
 import align_and_check,highlight_render,speaker_check
 track=data['track']
 align_and_check.process(track)
 report=read(job/'ending-check.json')
 if report['review_count']:
  raise ValueError(f"어미·대본 자동 검사에서 {report['review_count']}개 문단을 확인해야 합니다. ending-check.json을 확인하세요. 기존 영상과 원본은 보존했습니다.")
 speaker_check.run(track)
 return highlight_render.render(track)
def main():
 for stream in [sys.stdout,sys.stderr]:
  if hasattr(stream,'reconfigure'):stream.reconfigure(encoding='utf-8',errors='replace')
 ap=argparse.ArgumentParser();ap.add_argument('command',choices=['doctor','register','import-voice','sample','synthesize','render','all'])
 ap.add_argument('--track',choices=['lecture','portfolio'],default='lecture');ap.add_argument('--audio');ap.add_argument('--transcript')
 args=ap.parse_args()
 if args.command=='doctor':doctor()
 elif args.command=='register':
  print('10~20초의 본인 녹음과 실제 읽은 문장을 적은 UTF-8 TXT 파일을 준비해 주세요.')
  print('파일 경로를 붙여 넣거나 파일을 이 창으로 끌어 놓으세요. 빈 입력은 취소입니다.')
  audio=input('녹음 파일 경로: ').strip().strip('"')
  if not audio:return
  transcript=input('전사 TXT 파일 경로: ').strip().strip('"')
  if not transcript:return
  import_voice(audio,transcript)
 elif args.command=='import-voice':
  if not args.audio or not args.transcript:raise ValueError('--audio와 --transcript를 지정해 주세요.')
  import_voice(args.audio,args.transcript)
 elif args.command=='sample':
  job=synthesize(args.track,1);assemble(job);print(f'확인할 샘플: {job/"narration.wav"}')
 elif args.command=='synthesize':synthesize(args.track)
 elif args.command=='render':render(ROOT/'output'/args.track)
 else:render(synthesize(args.track))
if __name__=='__main__':
 try:main()
 except Exception as e:print(f'오류: {e}',file=sys.stderr);sys.exit(1)
