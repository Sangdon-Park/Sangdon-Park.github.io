@echo off
pushd "%~dp0"
powershell.exe -NoProfile -Command "$taskConfig = Get-Content -LiteralPath 'config.json' -Raw | ConvertFrom-Json; & $taskConfig.python -X utf8 presentation_tts.py register; exit $LASTEXITCODE"
set "taskCode=%ERRORLEVEL%"
echo.
pause
popd
exit /b %taskCode%
