"""Explicit official-example voice test; never registers the user's voice."""
from pathlib import Path
import json,urllib.request,re,time,sys
import numpy as np,soundfile as sf,torch
import presentation_tts as pt
R=Path(__file__).parent;C=pt.cfg();job=R/'checks'/'example-voice';job.mkdir(parents=True,exist_ok=True)
ref=job/'official-reference.wav'
if not ref.exists():urllib.request.urlretrieve('https://qianwen-res.oss-cn-beijing.aliyuncs.com/Qwen3-TTS-Repo/clone.wav',ref)
reftext='Okay. Yeah. I resent you. I love you. I respect you. But you know what? You blew it! And thanks to you.'
sentences=['이 음성은 설치 확인을 위한 예제입니다. 교수님의 목소리는 아직 등록하지 않았습니다.',
 '녹음 파일을 등록하면 발표 원고를 읽고, 자막과 슬라이드를 연결해 영상으로 만들 수 있습니다.',
 '포트폴리오에는 내가 맡은 일과 기술을 선택한 이유, 그리고 실제로 확인한 결과를 적습니다. 아직 하지 않은 일은 앞으로의 계획으로 구분합니다.']
images=['assets/lecture/slide_01.png','assets/lecture/slide_02.png','assets/portfolio/slide_01.png']
started=time.time();model=pt.load_model(C)
prompt=model.create_voice_clone_prompt(ref_audio=str(ref),ref_text=reftext,x_vector_only_mode=False)
rows=[]
for i,t in enumerate(sentences,1):
 with torch.inference_mode():
  waves,sr=model.generate_voice_clone(text=t,language='Korean',voice_clone_prompt=prompt,non_streaming_mode=True,max_new_tokens=1800)
 w,q=pt.audio_check(waves[0],sr,t);name=f'example_{i:02d}.wav';sf.write(job/name,w,sr,subtype='PCM_16')
 rows.append({'number':i,'title':'설치 검사 예제 음성','image':images[i-1],'segments':[{'caption':t,'speech':t,'file':name,'seconds':len(w)/sr,'sample_rate':sr}]})
 print(f'Example {i}: {len(w)/sr:.2f}s',flush=True)
del model;torch.cuda.empty_cache()
pt.write(job/'timing.json',{'track':'installation-test','is_user_voice':False,'complete':False,'slides':rows})
pt.render(job)
from faster_whisper import WhisperModel
asr=WhisperModel(C['asr_model'],device='cpu',compute_type='int8',local_files_only=True)
segments,_=asr.transcribe(str(job/'narration.wav'),language='ko',beam_size=5)
recognized=' '.join(s.text.strip() for s in segments)
def clean(t):return re.sub(r'[^가-힣a-z0-9]','',t.lower())
a,b=clean(' '.join(sentences)),clean(recognized)
cost=list(range(len(b)+1))
for i,x in enumerate(a,1):
 nxt=[i]
 for j,y in enumerate(b,1):nxt.append(min(nxt[-1]+1,cost[j]+1,cost[j-1]+(x!=y)))
 cost=nxt
report={'purpose':'installation test using official example voice; not the user voice','generation_and_test_seconds':time.time()-started,'expected':' '.join(sentences),'recognized':recognized,'character_error_rate':cost[-1]/max(1,len(a)),
 'video':str(job/'presentation.mp4'),'user_reference_exists':(R/C['reference_audio']).exists()}
pt.write(R/'checks'/'smoke-test.json',report)
assert not report['user_reference_exists'],'Example voice must not be registered as the user voice'
print(json.dumps(report,ensure_ascii=False,indent=2))
assert report['character_error_rate']<=0.15,'Speech transcription differs materially from the test text'
