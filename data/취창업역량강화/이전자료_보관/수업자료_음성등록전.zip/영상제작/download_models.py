"""Download pinned official models, with resumable ranges for large weights."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import os,json,time,hashlib,shutil
os.environ.pop('HF_HUB_OFFLINE',None)
os.environ.pop('TRANSFORMERS_OFFLINE',None)
os.environ['HF_HUB_DISABLE_TELEMETRY']='1'
os.environ.setdefault('HF_HUB_DISABLE_XET','1')
import requests
from huggingface_hub import HfApi,hf_hub_download
R=Path(__file__).parent

def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(4*1024*1024),b''):h.update(block)
 return h.hexdigest()

def large_file(repo,revision,item,local):
 target=Path(local)/item.rfilename;size=item.lfs.size;sha=item.lfs.sha256
 if target.exists() and target.stat().st_size==size and digest(target)==sha:
  print('Verified '+item.rfilename,flush=True);return
 parts=Path(local)/'.range-download'/item.rfilename.replace('/','_');parts.mkdir(parents=True,exist_ok=True)
 chunk=32*1024*1024;count=(size+chunk-1)//chunk
 def one(i):
  start=i*chunk;end=min(size,start+chunk)-1;p=parts/f'{i:05d}.part'
  if p.exists() and p.stat().st_size==end-start+1:return
  url=f'https://huggingface.co/{repo}/resolve/{revision}/{item.rfilename}?range_part={i}'
  for attempt in range(5):
   try:
    with requests.get(url,headers={'Range':f'bytes={start}-{end}'},stream=True,timeout=(20,60)) as response:
     response.raise_for_status()
     if response.status_code!=206 or response.headers.get('Content-Range')!=f'bytes {start}-{end}/{size}':
      raise ValueError('Unexpected ranged download response')
     temporary=p.with_suffix('.partial')
     with temporary.open('wb') as dst:
      for block in response.iter_content(1024*1024):dst.write(block)
     if temporary.stat().st_size!=end-start+1:raise ValueError('Incomplete range')
     temporary.replace(p);return
   except Exception:
    if attempt==4:raise
    time.sleep(2*(attempt+1))
 with ThreadPoolExecutor(max_workers=8) as pool:
  futures=[pool.submit(one,i) for i in range(count)]
  for done,future in enumerate(as_completed(futures),1):
   future.result()
   if done%8==0 or done==count:print(f'{item.rfilename}: {done}/{count} parts',flush=True)
 target.parent.mkdir(parents=True,exist_ok=True);temporary=target.with_suffix('.verified-download')
 with temporary.open('wb') as dst:
  for i in range(count):
   with (parts/f'{i:05d}.part').open('rb') as src:shutil.copyfileobj(src,dst,4*1024*1024)
 if digest(temporary)!=sha:raise ValueError('SHA256 mismatch for '+item.rfilename)
 temporary.replace(target)
 for i in range(count):(parts/f'{i:05d}.part').unlink()
 print('SHA256 verified '+item.rfilename,flush=True)

def main():
 config=json.loads((R/'config.json').read_text(encoding='utf-8'))
 models=[('Qwen/Qwen3-TTS-12Hz-1.7B-Base',config['model']),('Systran/faster-whisper-small',config['asr_model'])]
 result=[]
 for repo,local in models:
  lock=json.loads((R/'models.lock.json').read_text(encoding='utf-8')) if (R/'models.lock.json').exists() else {}
  info=HfApi().model_info(repo,revision=lock.get(repo),files_metadata=True);revision=info.sha
  print('Downloading '+repo+' @ '+revision,flush=True);started=time.time();weights=[]
  for item in info.siblings:
   if Path(item.rfilename).suffix not in ['.json','.txt','.safetensors','.bin','.model','.md']:continue
   if item.lfs and item.lfs.size>100*1024*1024:
    large_file(repo,revision,item,local)
    weights.append({'file':item.rfilename,'bytes':item.lfs.size,'sha256':item.lfs.sha256,'verified':True})
   else:hf_hub_download(repo,item.rfilename,revision=revision,local_dir=local)
  files=[p for p in Path(local).rglob('*') if p.is_file() and '.cache' not in p.relative_to(local).parts and '.range-download' not in p.relative_to(local).parts]
  row={'repo':repo,'revision':revision,'path':str(local),'file_count':len(files),'bytes':sum(p.stat().st_size for p in files),'download_seconds':time.time()-started,'weights':weights}
  result.append(row);(R/'checks').mkdir(exist_ok=True)
  (R/'checks'/'model-downloads.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
  print(json.dumps(row),flush=True)
 print('All model downloads complete.',flush=True)
if __name__=='__main__':main()
